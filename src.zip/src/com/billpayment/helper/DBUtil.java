package com.billpayment.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public abstract class DBUtil {
	private static Connection connection = null;

	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("mysql"); 
		String url = rb.getString("db.url");
		String user = rb.getString("db.username");
		String password = rb.getString("db.password");

		          

		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection(url, user, password);
		System.out.println("Connection Successful");
		return connection;

	}

	public static void closeConnection() throws SQLException {
		if (connection != null) {
			connection.close();
		}
	}

}
