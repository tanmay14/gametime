package com.billpayment.test;

import java.sql.SQLException;
import java.text.ParseException;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.billpayment.dao.CustomerDAO;
import com.billpayment.entity.Customer;
import com.billpayment.exception.DatabaseException;

public class CustomerDaoTest {

	CustomerDAO customerDao;
	Customer customer;

	@Before
	public void setUp() throws Exception {
		customerDao = new CustomerDAO();

	}

	@After
	public void tearDown() throws Exception {
		customerDao = null;
	}

	@Test
	public void testInsertRecordPositive() throws ParseException {
		customer = new Customer();
		int status1 = 0;
		int status2 = 0;

		customer.setAddress("cdc");
		customer.setCardNo("1234567890123456");
		customer.setContactNo("9876543210");
		customer.setCountryName("India");
		customer.setDocumentdetailnumber("ab12");
		customer.setDocumentNo("PASS12345");
		customer.setEmail("x@y.com");
		customer.setCustid(16);
		customer.setName("my_name");
		customer.setStateName("Assam");
		customer.setVendorName("sdf");
		customer.setVendorType("Tax");

		try {

			status1 = customerDao.insertCustRecord(customer);

			status2 = customerDao.insertCVMaster(customer);

		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		if (status1 * status2 != 0) {
			status1 = 1;
			status2 = 1;
		}
		Assert.assertEquals(1, (status1 * status2));
	}

	@Ignore
	@Test(expected = SQLException.class)
	public void testInsertRecordNegative() throws ClassNotFoundException,
			SQLException, ParseException {
		customer = new Customer();

		customer.setAddress("cdc");
		customer.setCardNo("123");
		customer.setContactNo("9876543210");
		customer.setCountryName("India");
		customer.setDocumentdetailnumber("ab12");
		customer.setDocumentName("passport");
		customer.setEmail("x@y.com");
		customer.setCustid(16);
		customer.setName("my_name");
		customer.setStateName("Assam");
		customer.setVendorName("sdf");
		customer.setVendorType("Tax");

		customerDao.insertCustRecord(customer);
	}

	@Test
	public void testFetchCustomerDetails() {

		customer = new Customer();

		try {
			customer = customerDao.fetchCustomerDetails(105);
			Assert.assertEquals("Anisha", customer.getName());
			Assert.assertEquals("955254007", customer.getContactNo());
			Assert.assertEquals("S ROAD", customer.getAddress());
			Assert.assertEquals("anigaikwad@gmail.com", customer.getEmail());
			Assert.assertEquals("9876543210123456", customer.getCardNo());

		} catch (ClassNotFoundException cnfe) {

			cnfe.printStackTrace();

		} catch (SQLException se) {

			se.printStackTrace();
		}
	}

	@Test
	public void testUpdateRecordPositive() throws ClassNotFoundException,
			SQLException, DatabaseException {
		customer = new Customer("Anisha", "955254007", "S ROAD", "PASS1234567",
				"anigaikwad@gmail.com", "9876543210123456", "Telephone",
				"aircel", "Passport", "India", "Maharashtra");
		customer.setCustid(105);
		int status = 0;

		try {
			status = customerDao.updateRecord(customer);
			Assert.assertEquals(1, status);
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();

		} catch (SQLException se) {
			se.printStackTrace();
		}

	}

}
