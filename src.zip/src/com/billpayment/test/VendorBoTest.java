package com.billpayment.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.BO.VendorBO;
import com.billpayment.entity.Vendor;

public class VendorBoTest {
	
	Vendor vendor;
	VendorBO vendorBo;

	@Before
	public void setUp() throws Exception {
		vendorBo=new VendorBO();
	}

	@After
	public void tearDown() throws Exception {
		vendorBo=null;
	}

	@Test
	public void testCalculateYOS() {
	vendor=new Vendor("aircel","Telephone","aircel1234", "S ROAD", "India", "Maharashtra", "aircel@gmail.com", "9552540007","aircel.com",900,1991);
	vendorBo.calculateYOS(vendor);
	Assert.assertEquals(24, vendor.getYos());
	}

	@Test
	public void testCalculateAmount() {
		
		vendor=new Vendor("aircel","Telephone","aircel1234", "S ROAD", "India", "Maharashtra", "aircel@gmail.com", "9552540007","aircel.com",900,1991);
		vendorBo.calculateAmount(vendor);
		Assert.assertEquals(2000f, vendor.getAmount());
		
		
	}

}
