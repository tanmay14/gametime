package com.billpayment.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.BO.CustomerBO;
import com.billpayment.entity.Customer;
import com.billpayment.exception.DatabaseException;

public class CustomerBoTest {

	CustomerBO customerBo;
	Customer customer;

	@Before
	public void setUp() throws Exception {
		customerBo = new CustomerBO();
	}

	@After
	public void tearDown() throws Exception {
		customerBo = null;
	}

	@Test
	public void testCalculatedocumentNO() throws DatabaseException {
		customer = new Customer("abc", "9988776655", "pune", "11223",
				"a@b.com", "123", "Telephone", "Aircel", "Passport", "India",
				"Assam");
		customerBo.calculatedocumentNO(customer);
		Assert.assertEquals("PASS11223", customer.getDocumentdetailnumber());
	}

}
