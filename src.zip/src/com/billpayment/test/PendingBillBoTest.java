package com.billpayment.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.BO.PendingBillsBO;
import com.billpayment.entity.PendingBillDetails;
import com.billpayment.exception.DatabaseException;

public class PendingBillBoTest {

	PendingBillsBO pendingBillBo;
	
	@Before
	public void setUp() throws Exception {
		pendingBillBo=new PendingBillsBO();
	}

	@After
	public void tearDown() throws Exception {
	pendingBillBo=null;
	}

	@Test
	public void testFetchList() throws DatabaseException {
		PendingBillDetails pbd=new PendingBillDetails();
		List<PendingBillDetails> actual=new ArrayList<PendingBillDetails>();
		List<PendingBillDetails> expected = new ArrayList<PendingBillDetails>();
		actual=pendingBillBo.fetchList(102);
		pbd.setName("Airtel");
		pbd.setPendingAmount(2000f);
		pbd.setType("Telephone");
		pbd.setVendorid(10000);
		expected.add(pbd);
		
		if (actual!=null) {
			Assert.assertEquals(1, 1);	
		}
		
	}

}
