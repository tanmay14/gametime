package com.billpayment.test;

import java.sql.SQLException;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.dao.BillDAO;

public class BillDaoTest {
	BillDAO billDao;

	@Before
	public void setUp() throws Exception {
		billDao=new BillDAO();
	}

	@After
	public void tearDown() throws Exception {
		billDao=null;
	}

	@Test
	public void testGetVendorId() {
		try{
			int vId = billDao.getVendorId("Aircel", "Telephone");
			Assert.assertEquals(10000, vId);
		}catch(ClassNotFoundException cnfe){
			cnfe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
	}

	@Test
	public void testGetCustomerIdPositive() throws ClassNotFoundException, SQLException {
		int cId = billDao.getCustomerId(101);
		Assert.assertEquals(101, cId);
	}
	
	@Test
	public void testGetCustomerIdNegative() {
		try{
		int cId = billDao.getCustomerId(1234);
		Assert.assertEquals(0, cId);
		}catch(ClassNotFoundException cnfe){
			cnfe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
	}

	@Test
	public void testPendingAmount() {
		try{
		float pendingAmt=billDao.pendingAmount(102, 10000);
		Assert.assertEquals(2000f, pendingAmt);
		}catch(ClassNotFoundException cnfe){
			cnfe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
	}

	@Test
	public void testUpdatePendingAmountDao() {
		int status=0;
		try
		{
			status=billDao.updatePendingAmountDao(102, 10000, 2000);
			Assert.assertEquals(1, status);
		}catch(ClassNotFoundException cnfe){
			cnfe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
	}

}
