package com.billpayment.test;

import java.sql.SQLException;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.dao.VendorDAO;
import com.billpayment.entity.Vendor;
import com.billpayment.exception.DatabaseException;

public class VendorDaoTest {
	VendorDAO vendorDao;
	Vendor vendor;

	@Before
	public void setUp() throws Exception {
		vendorDao = new VendorDAO();

	}

	@After
	public void tearDown() throws Exception {
		vendorDao = null;

	}

	@Test
	public void testInsertRecordPositive() {

		vendor = new Vendor();

		vendor.setVendorId(10);

		vendor.setAddress("cdc");
		vendor.setAmount(2f);
		vendor.setCompanyRegNo("p1");
		vendor.setContactNo("9988776655");
		vendor.setCountry("India");

		vendor.setEmailid("a@bcd.com");
		vendor.setEmployeeCount(20);
		vendor.setName("MEB2");
		vendor.setState("Assam");
		vendor.setType("Electricity");

		vendor.setWebsite("www.sdf.com");
		vendor.setYoe(2010);
		vendor.setYos(2015);

		int status = 0;
		try {
			status = vendorDao.insertRecord(vendor);

		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
		if (status != 0) {
			status = 1;
		}
		Assert.assertEquals(1, status);
	}

	@Test
	// (expected = SQLException.class)
	public void testInsertRecordNegative() throws ClassNotFoundException,
			SQLException {

		vendor = new Vendor();

		vendor.setVendorId(10);

		vendor.setAddress("cdc");
		vendor.setAmount(2f);
		vendor.setCompanyRegNo("p1");
		vendor.setContactNo("9988776655");
		vendor.setCountry("India");

		vendor.setEmailid("a@b.com");
		vendor.setEmployeeCount(20);
		vendor.setName("Reliance");
		vendor.setState("Assam");
		vendor.setType("Electricity");

		vendor.setWebsite("www.sdf.com");
		vendor.setYoe(2010);
		vendor.setYos(2015);

		vendorDao.insertRecord(vendor);
	}

	@Test
	public void testFetchVendorDetailsPositive() {

		vendor = new Vendor();

		try {
			vendor = vendorDao.fetchVendorDetails(10000);

			Assert.assertEquals("Aircel", vendor.getName());
			Assert.assertEquals("aircel1234", vendor.getCompanyRegNo());
			Assert.assertEquals("Telephone", vendor.getType());
			Assert.assertEquals("S ROAD", vendor.getAddress());
			Assert.assertEquals("Maharashtra", vendor.getState());
			Assert.assertEquals("aircel@gmail.com", vendor.getEmailid());
			Assert.assertEquals("9552540007", vendor.getContactNo());
			Assert.assertEquals("aircel.com", vendor.getWebsite());
			Assert.assertEquals(900, vendor.getEmployeeCount());
			Assert.assertEquals(2015, vendor.getYoe());

		} catch (ClassNotFoundException cnfe) {

			cnfe.printStackTrace();

		} catch (SQLException se) {

			se.printStackTrace();
		}

	}

	@Test
	public void testUpdateRecordPositive() throws ClassNotFoundException,
			SQLException, DatabaseException {
		vendor = new Vendor("Aircel", "Telephone", "aircel1234", "S ROAD",
				"India", "Maharashtra", "aircel@gmail.com", "9552540007",
				"aircel.com", 900, 1991);
		vendor.setVendorId(10000);
		int status = 0;

		try {
			status = vendorDao.updateRecord(vendor);
			Assert.assertEquals(1, status);
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

}
