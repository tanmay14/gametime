package com.billpayment.test;

import java.sql.SQLException;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.billpayment.BO.BillPaymentBO;
import com.billpayment.exception.DatabaseException;

public class BillBoTest {

	BillPaymentBO billBo;
	
	@Before
	public void setUp() throws Exception {
	billBo = new BillPaymentBO();
	}

	@After
	public void tearDown() throws Exception {
	billBo = null;
	}

	@Test
	public void testValidateVendorPositive() throws DatabaseException {
		boolean status=false;
		try{
			status = billBo.validateVendor("Aircel", "Telephone");
			Assert.assertEquals(true, status);
		}catch(DatabaseException de){
			de.printStackTrace();
		}
		
		
	}
	@Test
	public void testValidateVendorNegative() throws DatabaseException {
		boolean status=false;
		try{
			status = billBo.validateVendor("xyz", "Telephone");
			Assert.assertEquals(false, status);
		}catch(DatabaseException de){
			de.printStackTrace();
		}
		
		
	}

	@Test
	public void testValidateCustomerPositive() {
		boolean status=false;
		try{
			status=billBo.validateCustomer(100);
			Assert.assertEquals(true, status);
		}catch(DatabaseException de){
			de.printStackTrace();
		}
	}
	
	@Test
	public void testValidateCustomerNegative() {
		boolean status=false;
		try{
			status=billBo.validateCustomer(1234);
			Assert.assertEquals(false, status);
		}catch(DatabaseException de){
			de.printStackTrace();
		}
	}

	@Test
	public void testGetPendingAmount() {
		float pendingAmt=0.0f;
		try{
			pendingAmt=billBo.getPendingAmount(102, "Aircel","Telephone");
			Assert.assertEquals(2000f, pendingAmt);
		}catch(DatabaseException de){
			de.printStackTrace();
		}
	}

	@Test
	public void testUpdatePendingAmount() throws SQLException {
		int status=0;
		try{
			status=billBo.updatePendingAmount(102,"Aircel" , "Telephone", 000f, 2000f);
			Assert.assertEquals(1, status);
		}catch(DatabaseException de){
			
		}
	}

}
