package com.billpayment.entity;

public class PendingBillDetails {
	private int vendorid;
	private String name;
	private String type;
	private float pendingAmount;

	public PendingBillDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PendingBillDetails(int vendorid, String name, String type,
			float pendingAmount) {
		super();
		this.vendorid = vendorid;
		this.name = name;
		this.type = type;
		this.pendingAmount = pendingAmount;
	}

	@Override
	public String toString() {
		return "PendingBillDetails [vendorid=" + vendorid + ", name=" + name
				+ ", type=" + type + ", pendingAmount=" + pendingAmount + "]";
	}

	public int getVendorid() {
		return vendorid;
	}

	public void setVendorid(int vendorid) {
		this.vendorid = vendorid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public float getPendingAmount() {
		return pendingAmount;
	}

	public void setPendingAmount(float pendingAmount) {
		this.pendingAmount = pendingAmount;
	}

}
