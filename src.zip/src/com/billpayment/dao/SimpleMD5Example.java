package com.billpayment.dao;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

public class SimpleMD5Example {
	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		String passwordToHash = "password";
		String generatedPassword = null;
		try {
			// Create MessageDigest instance for MD5
			MessageDigest md = MessageDigest.getInstance("MD5");
			// Add password bytes to digest
			md.update(passwordToHash.getBytes());
			// Get the hash's bytes
			byte[] bytes = md.digest();
			// This bytes[] has bytes in decimal format;
			// Convert it to hexadecimal format
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16)
						.substring(1));
			}
			// Get complete hashed password in hex format
			generatedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		// System.out.println(generatedPassword);
		/*
		 * Connection con = null; boolean status = false; int records = 0;
		 * String query = "insert into admin values(?,?)"; PreparedStatement pst
		 * = null; try { con = DBUtil.createConnection();
		 * 
		 * pst = con.prepareStatement(query);
		 * 
		 * pst.setString(1, "admin"); pst.setString(2, generatedPassword);
		 * 
		 * records = pst.executeUpdate();
		 * 
		 * } finally { DBUtil.closeConnection(); if (con != null) { con.close();
		 * 
		 * } }
		 */

	}
}