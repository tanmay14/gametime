package com.billpayment.BO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.billpayment.dao.StateDAO;

public class StateBO {
	public Map<String, String> fetchStates(final String country) {
		ArrayList<String> states = new ArrayList<String>();
		Map<String, String> India = new LinkedHashMap<String, String>();
		StateDAO vdao = new StateDAO();
		states = vdao.fetchIndiaStates(country);
		Iterator<String> itr_states = states.iterator();

		while (itr_states.hasNext()) {

			String s2 = itr_states.next();

			India.put(s2, s2);
		}
		return India;

	}

	

}
