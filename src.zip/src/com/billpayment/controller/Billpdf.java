package com.billpayment.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

/**
* Servlet implementation class pdf
*/
public class Billpdf extends HttpServlet {
                private static final long serialVersionUID = 1L;

                /**
                * @see HttpServlet#HttpServlet()
                */
                public Billpdf() {
                                super();
                                // TODO Auto-generated constructor stub
                }

                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
                *      response)
                */
                protected void doGet(HttpServletRequest request,
                                                HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                      doPost(request, response);          

                }

                /**
                * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
                *      response)
                */
                protected void doPost(HttpServletRequest request,
                                                HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                	Document document = new Document();
                    try {
                                    response.setContentType("application/pdf");
                                    PdfWriter.getInstance(document, response.getOutputStream());
                                    document.open();
                                    document.add(new Paragraph("howtodoinjava.com"));
                                    document.add(new Paragraph(new Date().toString()));
                                    // Add more content here
                    } catch (Exception e) {
                                    e.printStackTrace();
                    }
                    document.close();
                }

}
