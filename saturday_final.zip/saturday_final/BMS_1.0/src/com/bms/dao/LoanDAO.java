package com.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;

import org.apache.log4j.Logger;

import com.bms.bean.LoanBean;
import com.bms.util.PropertyUtil;

public class LoanDAO {
	private Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	PreparedStatement ps = null;
	PropertyUtil util = new PropertyUtil();
	public static Logger LOG = Logger.getLogger(LoanDAO.class);

	public double getInitialDeposit(String CustId)
			throws ClassNotFoundException, SQLException {
		LOG.info("Inside LoanDAO,getinitialdeposit()");
		double e = 0;
		try {
			conn = util.connections();
			String sql = "select Initial_Deposit_Amount from Account_Info where Customer_Id like "
					+ "'" + CustId + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next())
				e = rs.getDouble(1);
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return e;
	}

	public boolean insertLoanDetails(LoanBean loan) throws SQLException,
			ClassNotFoundException, ParseException {
		LOG.info("Inside LoanDAO,insertLoanDetails()");
		boolean flag = false;
		java.sql.Date sqlDate = null;
		try {
			conn = util.connections();
			if (loan.getLoanType().equalsIgnoreCase("educational")) {
				String sql1 = "insert into Loan_Details(Loan_Id,Account_Number,Loan_Type,Loan_Amount,Loan_Apply_Date,Loan_Issue_Date,"
						+ "Duration_Of_Loan,Course_Fees,Course_Name,Father_Name,Father_Occupation,Father_Total_Experience,"
						+ "Father_Experience_Company,Ration_Card_Number,Annual_Income,Loan_Acc_No,EMI)"
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				ps = conn.prepareStatement(sql1);
				ps.setString(1, loan.getLoanId());
				String accno = getAccountNo(loan.getCustid());
				ps.setString(2, accno);
				ps.setString(3, loan.getLoanType());
				ps.setDouble(4, loan.getLoanAmount());
				sqlDate = util.utilDateToSqlDate(loan.getLoanApplyDate());
				ps.setDate(5, sqlDate);
				sqlDate = util.utilDateToSqlDate(loan.getLoanIssueDate());
				ps.setDate(6, sqlDate);
				ps.setInt(7, loan.getDurationLoan());
				ps.setDouble(8, loan.getCourseFee());
				ps.setString(9, loan.getCourse());
				ps.setString(10, loan.getFatherName());
				ps.setString(11, loan.getFatherOccupation());
				ps.setInt(12, loan.getFatherTotalExp());
				ps.setInt(13, loan.getFatherExpwCC());
				ps.setString(14, loan.getRationCard());
				ps.setDouble(15, loan.getAnnualIncome());
				ps.setString(16, loan.getLoanAccNo());
				ps.setDouble(17, loan.getEMI());

				if (ps.executeUpdate() > 0)
					flag = true;
			} else {
				String sql = "insert into Loan_Details(Loan_Id,Account_Number,Loan_Type,Loan_Amount,Loan_Apply_Date,Loan_Issue_Date,"
						+ "Duration_Of_Loan,Customer_Annual_Income,Customer_Company_Name,Customer_Designation,"
						+ "Customer_Total_Experience,Customer_Experience_Company,Loan_Acc_No,EMI,GuarantorName,GuarantorAddress,GuarantorIncome)"
						+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				ps = conn.prepareStatement(sql);
				ps.setString(1, loan.getLoanId());
				String accno = getAccountNo(loan.getCustid());
				ps.setString(2, accno);
				ps.setString(3, loan.getLoanType());
				ps.setDouble(4, loan.getLoanAmount());
				sqlDate = util.utilDateToSqlDate(loan.getLoanApplyDate());
				ps.setDate(5, sqlDate);
				sqlDate = util.utilDateToSqlDate(loan.getLoanIssueDate());
				ps.setDate(6, sqlDate);
				ps.setInt(7, loan.getDurationLoan());
				ps.setDouble(8, loan.getAnnualIncome());
				ps.setString(9, loan.getCompanyName());
				ps.setString(10, loan.getDesignation());
				ps.setInt(11, loan.getTotalExp());
				ps.setInt(12, loan.getExpCC());
				ps.setString(13, loan.getLoanAccNo());
				ps.setDouble(14, loan.getEMI());
				ps.setString(15, loan.getGuarantorName());
				ps.setString(16, loan.getGuarantorAddress());
				ps.setDouble(17, loan.getGuarantorIncome());
				if (ps.executeUpdate() > 0)
					flag = true;
			}
		} finally {
			if (ps != null)
				ps.close();
		}
		return flag;
	}

	private String getAccountNo(String CustId) throws ClassNotFoundException,
			SQLException {
		LOG.info("Inside LoanDAO,getaccountno()");
		String accno = null;
		try {
			conn = util.connections();
			String sql = "select Account_Number from Account_Info where Customer_Id like "
					+ "'" + CustId + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next())
				accno = rs.getString(1);
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return accno;
	}

	public String[] getLoanId() throws ClassNotFoundException, SQLException {
		LOG.info("Inside LoanDAO,getLoanid()");
		String s[] = { "0", "0" };
		try {
			conn = util.connections();
			String sql = "select count(*) from Loan_Details";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			s[0] = String.valueOf(num);
			if (num > 0) {
				sql = "select Loan_Id from Loan_Details limit " + (num - 1)
						+ ",1";
				rs = stmt.executeQuery(sql);
				if (rs.next())
					s[1] = rs.getString(1);
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return s;
	}

	public String[] getLoanAccNo() throws ClassNotFoundException, SQLException {
		LOG.info("Inside LoanDAO,getLoanAccNo()()");
		String s[] = { "0", "0" };
		try {
			conn = util.connections();
			String sql = "select count(*) from Loan_Details";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			s[0] = String.valueOf(num);
			if (num > 0) {
				sql = "select Loan_Id from Loan_Details limit " + (num - 1)
						+ ",1";
				rs = stmt.executeQuery(sql);
				if (rs.next())
					s[1] = rs.getString(1);
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return s;
	}

	public String getCitizenStatus(String CustId)
			throws ClassNotFoundException, SQLException {
		LOG.info("Inside LoanDAO,getCitizenStatus()");
		String CS = null;
		try {
			conn = util.connections();
			String sql = "select Citizen_Status from Customer_Details where Customer_Id like "
					+ "'" + CustId + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				CS = rs.getString(1);
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return CS;
	}
}
