package com.bms.bo;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.TransactionBean;
import com.bms.dao.TransactionDAO;

public class TransactionBO {
	public static Logger LOG = Logger.getLogger(TransactionBO.class);

	public String[] checkAmount(TransactionBean user, String CustIdOfLogin)
			throws BusinessException, SQLException, ParseException,
			ClassNotFoundException {
		LOG.info("inside TransactionBO-validiation of User(Transaction Bean) Check");
		String check[] = { "0", "0", "0" };
		Transaction_Amount_valid(user, CustIdOfLogin);
		TransactionDAO trandao = new TransactionDAO();
		check = trandao.insertUser(user, CustIdOfLogin);
		return check;
	}

	private void Transaction_Amount_valid(TransactionBean user,
			String custIdOfLogin) throws SQLException, BusinessException,
			ClassNotFoundException {
		LOG.info("inside TransactionBO-validiation of Transaction Amount");
		TransactionDAO trandao = new TransactionDAO();
		ArrayList<Integer> list = new ArrayList<Integer>();
		list = trandao.checkAmount(user, custIdOfLogin);
		Iterator<Integer> i = list.iterator();
		int val = 0;
		while (i.hasNext()) {
			val = i.next();
			switch (val) {
			case 1:
				throw new BusinessException(
						"Sorry!! No sufficient funds to do this transaction");
			case 2:
				throw new BusinessException(
						"Sorry!! minimum remaining balance should be greater than initial deposit amount");
			case 3:
				throw new BusinessException(
						"Sorry!!  minimum remaining balance should be greater than initial deposit amount");
			case 4:
				throw new BusinessException(
						"Sorry!! No sufficient funds to do this transaction ");
			case 5:
				throw new BusinessException(
						"Sorry!!  minimum remaining balance should be greater than initial deposit amount");
			case 6:
				throw new BusinessException(
						"Sorry!!  minimum remaining balance should be greater than initial deposit amount");
			case 7:
				throw new BusinessException(
						"Loan Amount is 0/Loan Amount already paid.");
			case 8:
				throw new BusinessException(
						"Entered amount is greater than Loan Amount to be paid.");
			}
		}
	}
}