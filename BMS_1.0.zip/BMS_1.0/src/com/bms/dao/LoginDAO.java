package com.bms.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.bms.bean.LoginBean;
import com.bms.util.PropertyUtil;

public class LoginDAO {
	private Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	PropertyUtil util = new PropertyUtil();
	public static Logger LOG = Logger.getLogger(LoginDAO.class);

	public String checkLogin(LoginBean lb) throws ClassNotFoundException,
			SQLException {
		// LOG.info("Inside LoginDAO,checkLOGIN()");
		// Boolean b = false;
		String s = new String();
		try {
			conn = util.connections();
			String sql = "select Customer_Id from login_table where UserName like "
					+ "'"
					+ lb.getUsername()
					+ "'"
					+ "and "
					+ "Password like "
					+ "'" + lb.getPassword() + "'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				s = rs.getString(1); // customer_id
				// b = true;
				// s[0] = String.valueOf(b); // flag value TRUE if data return
			} /*
			 * else { b = false; s[0] = String.valueOf(b); // flag value FALSE
			 * if no data return }
			 */
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return s;
	}
}
