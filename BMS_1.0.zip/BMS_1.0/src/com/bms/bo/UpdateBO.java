package com.bms.bo;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.UpdateBean;
import com.bms.dao.UpdateDAO;
import com.bms.util.PropertyUtil;

public class UpdateBO {
	public static Logger LOG = Logger.getLogger(UpdateBO.class);
	PropertyUtil util = new PropertyUtil();

	private void validGuardianName(String Guardian_Name)
			throws BusinessException {
		LOG.info("inside UpdateBO  guardian name valid");
		for (int i = 0; i < Guardian_Name.length(); i++) {
			char c = Guardian_Name.charAt(i);
			if (!Character.isLetter(c) && !Character.isSpace(c)) {
				throw new BusinessException(
						"Guardian Name can contain only alphabets and spaces");
			}
		}
	}

	private void validateName(String Name) throws BusinessException {
		LOG.info("inside UpdateBO name valid");
		for (int i = 0; i < Name.length(); i++) {
			char c = Name.charAt(i);
			if (!Character.isLetter(c) && !Character.isSpace(c)) {
				throw new BusinessException(
						"Name can contain only alphabets and spaces");
			}
		}
	}

	private void validateDOB(String DOB) throws BusinessException,
			ParseException {
		LOG.info("inside UpdateBO  date valid");
		if (DOB.equals(null))
			throw new BusinessException("Date of birth cannot be blank");
		else {
			Date d = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
			Date d2 = sdf.parse(DOB);
			if (d2.compareTo(d) < 0) {
			} else
				throw new BusinessException(
						"Date of birth should be greater than sytem's date");
		}
	}

	private void validateIdDoc(String Identification_doc_number, String cust_id)
			throws BusinessException, SQLException, ClassNotFoundException {
		boolean b;
		LOG.info("inside UpdateBO  doc number");
		String iddoc_val = "[A-Za-z0-9]{12}[^<>'\"/;`%]*$";
		if (Identification_doc_number.equals(null))
			throw new BusinessException(
					"Identification document cannot be blank");
		else {
			b = Identification_doc_number.matches(iddoc_val);
			if (b == false)
				throw new BusinessException("Invalid document number");
			else {
				UpdateDAO dao = new UpdateDAO();
				boolean b1 = false;
				b1 = dao.validDocNo(Identification_doc_number, cust_id);
				if (b1 == true)
					throw new BusinessException(
							"Identification document number  already exist in the system");
			}
			LOG.info("inside UpdateBO  after validating Identification Document no valid   "
					+ Identification_doc_number);
		}
	}

	private void validateAdd(String Address) throws BusinessException {
		LOG.info("inside UpdateBO   add valid");
		if (Address.equals(null))
			throw new BusinessException("Address cannot be blank");
	}

	private void validateContactNo(Long Contact_number)
			throws BusinessException {
		LOG.info("inside UpdateBO  contact number valid");
		String contact_no = "\\d{10}";
		String s = String.valueOf(Contact_number);
		if (!s.matches(contact_no))
			throw new BusinessException("Invalid contact number");
	}

	private void ageValid(String DOB, String Citizen_Status)
			throws BusinessException, ParseException {
		LOG.info("inside UpdateBO  age valid");
		if (DOB.equals(null))
			throw new BusinessException("Date of birth cannot be blank");
		else {
			if (Citizen_Status.equals("minor"))
				throw new BusinessException(
						"Customer should be minimum of 18 years");
		}
	}

	private void validateMailId(String Mail_Id) throws BusinessException {
		LOG.info("inside UpdateBO  emailid valid");
		boolean b;
		if (Mail_Id == null)
			throw new BusinessException("Email cannot be blank");
		String email = "^[\\w-_\\.+]*[\\w-_\\.]"
				+ "\\@([\\w]+\\.)+[\\w]+[\\w]$";
		b = Mail_Id.matches(email);
		if (b == false)
			throw new BusinessException("Invalid email id");

	}

	private void validateCitiStatus(String Citizen_Status)
			throws BusinessException {
		LOG.info("inside UpdateBO  citizenstatus valid");
		if (Citizen_Status.equals(null))
			throw new BusinessException("Citizen status cannot be blank");
	}

	private void Reference_account_holder_account_number(
			String ref_acc_holder_no, String reference_name,
			String reference_address) throws SQLException, BusinessException,
			BusinessException {
		LOG.info("inside UpdateBO reference account holder account number validation   "
				+ ref_acc_holder_no);
		if (ref_acc_holder_no.equals(null))
			throw new BusinessException(
					"Reference account holder account number cannot be blank");
		ArrayList<String> list = new ArrayList<String>();
		list = util.refAccNo(ref_acc_holder_no);
		Iterator<String> iterator = list.iterator();
		int i = 0;
		while (iterator.hasNext()) {
			if ((iterator.next().equalsIgnoreCase(reference_name))) {
				i++;
				if ((iterator.next().equalsIgnoreCase(reference_address))) {
					i++;
				} else
					throw new BusinessException(
							"Invalid reference account holder");
			} else
				throw new BusinessException("Invalid reference account holder");
		}
		LOG.info("inside RegistrationBO  after validating reference account holder account number validation   "
				+ ref_acc_holder_no);
	}

	public boolean updateUser(UpdateBean user) throws BusinessException,
			ParseException, ClassNotFoundException, SQLException,
			BusinessException {
		LOG.info("inside UpdateBO  ,updateuser");
		validateName(user.getName());
		validateDOB(user.getDOB());
		validateIdDoc(user.getIdentification_doc_number(),
				user.getCustomer_Id());
		validateAdd(user.getAddress());
		validateAdd(user.getAlternateAddress());
		validateMailId(user.getMail_Id());
		validGuardianName(user.getGuardian_Name());
		ageValid(user.getDOB(), user.getCitizen_Status());
		validateContactNo(user.getContact_number());
		validateContactNo(user.getAlternateContact_number());
		validateCitiStatus(user.getCitizen_Status());
		Reference_account_holder_account_number(
				user.getReference_account_holder_account_number(),
				user.getReference_account_holder_name(),
				user.getReference_account_holder_address());
		boolean flag = false;
		UpdateDAO udao1 = new UpdateDAO();
		boolean flag1;
		try {
			flag1 = udao1.updateUser(user);
			if (flag1 == true)
				flag = true;
			else
				flag = false;
		} catch (Exception e) {
			LOG.error("Exception from UpdateBO " + e.getMessage());
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
}
