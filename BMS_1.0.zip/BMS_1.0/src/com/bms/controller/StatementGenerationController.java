package com.bms.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import com.bms.bean.StatementGenerationBean;
import com.bms.bo.StatementGenerationBO;
import com.bms.BusinessException.*;

public class StatementGenerationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG =Logger.getLogger(StatementGenerationController.class);

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(true);
		if(session.getAttribute("Customer_Id")==null){
			response.sendRedirect("Login.jsp");
		}
		try {
			LOG.info("inside Statement Generation controller");
			StatementGenerationBean bean=new StatementGenerationBean();
			StatementGenerationBO bo=new StatementGenerationBO();
			bean.setCustomer_Id((String)session.getAttribute("Customer_Id"));
			if(request.getParameter("From_Date").isEmpty())
				throw new BusinessException("From_Date cannot be null");
			bean.setFrom_Date(request.getParameter("From_Date"));
			if(request.getParameter("To_Date").isEmpty())
				throw new BusinessException("To_Date cannot be null");
			bean.setTo_Date(request.getParameter("To_Date"));
			if(request.getParameter("Transaction_Type").equalsIgnoreCase(""))
				throw new BusinessException("Transaction Type cannot be null");
			bean.setTransaction_Type(request.getParameter("Transaction_Type"));
			if(request.getParameter("Transaction").isEmpty())
				throw new BusinessException("Transaction per page cannot be null");
			LOG.info("inside Statement Generation controller after setting all the fields");
			bean.setTransaction(request.getParameter("Transaction"));
			String check[]=bo.checkTransaction(bean);
			int NumOfTrans=Integer.parseInt(check[1]);
			if(check[0].equalsIgnoreCase("1")){   
				LOG.info("inside Statement Generation controller transaction exist");
				if(request.getParameter("downloadView").equalsIgnoreCase("view")){ 
					if(NumOfTrans<=500){  
						session.setAttribute("object1", bean);
						RequestDispatcher dispatch=request.getRequestDispatcher("StatementGenerationView.jsp");
						dispatch.forward(request, response);
					}else{   
						request.setAttribute("message", "MoreThan500");
						RequestDispatcher dispatch=request.getRequestDispatcher("StatementGeneration.jsp");
						dispatch.forward(request, response);	
					}
				}
				if(request.getParameter("downloadView").equalsIgnoreCase("download")){
					request.setAttribute("object1",bean);
					request.setAttribute("message", "download");
					RequestDispatcher dispatch=request.getRequestDispatcher("StatementGeneration.jsp");
					dispatch.forward(request, response);
				}
			}
		}catch (BusinessException e){
			LOG.error("inside Statement Generation controller transaction business exception"+e.getMessage());
			request.setAttribute("error", e.getMessage());
			RequestDispatcher dispatch=request.getRequestDispatcher("StatementGeneration.jsp");
			dispatch.forward(request, response);
		}catch (Exception e){
			LOG.error("inside Statement Generation controller transaction error occurs"+e.getMessage());
			request.setAttribute("message", "error");
			RequestDispatcher dispatch=request.getRequestDispatcher("StatementGeneration.jsp");
			dispatch.forward(request, response);
		}
	}
}


