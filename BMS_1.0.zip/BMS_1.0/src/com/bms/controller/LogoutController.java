package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

public class LogoutController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(LogoutController.class);

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);

		request.removeAttribute("Customer_Id");
		request.removeAttribute("username");
		session.removeAttribute("Customer_Id");
		session.removeAttribute("username");

		session.invalidate();

		LOG.info("Session invalidated");

		RequestDispatcher dispatch = request.getRequestDispatcher("Login.jsp");
		dispatch.forward(request, response);
	}
}
