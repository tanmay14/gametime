package com.bms.bean;

public class StatementGenerationBean {
private String From_Date;
private String To_Date;
private String Transaction_Type;
private String Transaction;
private String Transaction_Date;
private String Transaction_Id;
private String Customer_Id;
private String description;
private String Amount;
private String Balance;
private String Cheque_Number;
public void setFrom_Date(String from_Date) {
	From_Date = from_Date;
}
public String getFrom_Date() {
	return From_Date;
}
public void setTo_Date(String to_Date) {
	To_Date = to_Date;
}
public String getTo_Date() {
	return To_Date;
}
public void setTransaction_Type(String transaction_Type) {
	Transaction_Type = transaction_Type;
}
public String getTransaction_Type() {
	return Transaction_Type;
}
public void setTransaction(String transaction) {
	Transaction = transaction;
}
public String getTransaction() {
	return Transaction;
}
public void setTransaction_Date(String transaction_Date) {
	Transaction_Date = transaction_Date;
}
public String getTransaction_Date() {
	return Transaction_Date;
}
public void setTransaction_Id(String transaction_Id) {
	Transaction_Id = transaction_Id;
}
public String getTransaction_Id() {
	return Transaction_Id;
}
public void setCustomer_Id(String customer_Id) {
	Customer_Id = customer_Id;
}
public String getCustomer_Id() {
	return Customer_Id;
}
public void setAmount(String amount) {
	Amount = amount;
}
public String getAmount() {
	return Amount;
}
public void setDescription(String description) {
	this.description = description;
}
public String getDescription() {
	return description;
}
public void setCheque_Number(String cheque_Number) {
	Cheque_Number = cheque_Number;
}
public String getCheque_Number() {
	return Cheque_Number;
}
public void setBalance(String balance) {
	Balance = balance;
}
public String getBalance() {
	return Balance;
}
}
