package com.cts.BNK.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.BNK.buss.InterfaceBank;
import com.cts.BNK.dao.CustomerLoginDao;
import com.cts.BNK.dao.TransactionDao;
import com.cts.BNK.model.BNKstatement;
import com.cts.BNK.model.CustomerLoginModel;
import com.cts.BNK.model.CustomerModel;
import com.cts.BNK.model.CustomerinfoModel;
import com.cts.BNK.model.LoanModel;
import com.cts.BNK.model.Model;
import com.cts.BNK.model.Registration;
import com.cts.BNK.model.TransModel;
import com.cts.BNK.util.BankFactory;

/**
 * Servlet implementation class BaseController
 */
public class BaseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String fname="";
	private static String lname="";
	private static String uname="";
	private static String cust_id=""; 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();

		// Block for Registration
		if (session.getAttribute("Formname").equals("Registration")) {
			Registration reg = (Registration) session.getAttribute("customer");
			session.setAttribute("custfname", reg.getFname());
			session.setAttribute("custlname", reg.getLname());
			uname=reg.getUsername();
			System.out.println("IN BANK CONTROLLER:REGISTRATION"+uname);
			fname=reg.getFname();
			lname=reg.getLname();
			InterfaceBank ibank = BankFactory.getClass("REGISTRATION",uname);
			try {
				String k = ibank.save(reg);
				session.setAttribute("customer_id", k);
				if (k != null) {
					cust_id=k;
					response.sendRedirect("RegistrationSuccess.jsp");
				} else {
					response.sendRedirect("RegistrationError.jsp");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (session.getAttribute("Formname").equals("Loan")) {
			LoanModel reg = (LoanModel) session.getAttribute("customer_loan");
			Registration reg1 = (Registration) session.getAttribute("customer");
			session.setAttribute("custfname_loan", fname);
			session.setAttribute("custlname_loan", lname);
//			uname=reg1.getUsername();
//			fname=reg1.getFname();
//			lname=reg1.getLname();
			InterfaceBank ibank = BankFactory.getClass("LoanModel",uname);
			try {
				String k = ibank.save(reg);
				session.setAttribute("loan_id", k);
				if (k != null) {
					response.sendRedirect("LoanSuccess.jsp");
				} else {
					response.sendRedirect("LoanError.jsp");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if (session.getAttribute("Formname").equals("Registrationpage")) {
			response.sendRedirect("Registration.jsp");
		}

		// Block for Customer Login
		else if (session.getAttribute("Formname").equals("Login")) {
			
			String UserName = (String) session.getAttribute("id"), password = (String) session
					.getAttribute("pass");
			uname=UserName;
			
			InterfaceBank impBank = BankFactory.getClass("CustomerLogin",UserName);
			CustomerLoginModel baseModel = new com.cts.BNK.model.CustomerLoginModel(
					UserName, password);
			TransactionDao tDao=new com.cts.BNK.dao.TransactionDao();
		     String cust_id=tDao.getCustomerId(UserName);
			//CustomerinfoModel cim=new TransactionDao().getAllValues(baseModel.getUsername());
			//String cust_id=cim.getCustomer_id();
		   CustomerLoginDao ob=new CustomerLoginDao();
		
			if (impBank.login(baseModel) != null) {
				{
					fname=baseModel.getFirstname();
					lname=baseModel.getLastname();
					System.out.println("IN BASE CONTROLLER:LOGIN"+fname);
					System.out.println("IN BASE CONTROLLER:LOGIN"+lname);
					//try{
						if (baseModel.getStatus().equalsIgnoreCase("yes")) {
							session.setAttribute("formname", "");
							session.setAttribute("state", "customer");
							session.setAttribute("user", baseModel);
							session.setAttribute("trans", cust_id);
							response.sendRedirect("CustomerHomePage.jsp");
						} else if (baseModel.getStatus()
								.equalsIgnoreCase("pending")) {
							session.setAttribute("formname", "");
							session.setAttribute("state", "customerPending");
							response.sendRedirect("CustomerPending.jsp");
						} else {
							session.setAttribute("formname", "");
							session.setAttribute("state", "customerRejected");
							response.sendRedirect("CustomerDeleted.jsp");
						}
					//}catch(Exception e){e.printStackTrace();}
				}
			} else {
				session.setAttribute("msg", "Incorect Login ID/ password");
				response.sendRedirect("Login.jsp");
			}
		}

		// Block for Login Session Management
		else if (session.getAttribute("Formname").equals("LoginState")) {
			if (session.getAttribute("state") != null
					&& session.getAttribute("state").equals("customer")) {
				response.sendRedirect("CustomerHomePage.jsp");
			} else if (session.getAttribute("state") != null
					&& session.getAttribute("state").equals("customerPending")) {
				response.sendRedirect("CustomerPending.jsp");
			} else if (session.getAttribute("state") != null
					&& session.getAttribute("state").equals("customerRejected")) {
				response.sendRedirect("CustomerDeleted.jsp");
			} else if (((String) session.getAttribute("state")).equals("admin")) {
				response.sendRedirect("AdminPage.jsp");
			} else {
				session.setAttribute("Formname", "HomePage.jsp");

			}

		}

		// Block for Administrator Log in
		else if (session.getAttribute("Formname").equals("AdminLogin")) {
			InterfaceBank impBank = BankFactory.getClass("AdminLogin",uname);
			String UserName = (String) session.getAttribute("id"), password = (String) session
					.getAttribute("pass");
			Model baseModel = new com.cts.BNK.model.AdminLoginModel(UserName,
					password);
			if (impBank.login(baseModel) != null) {
				session.setAttribute("formname", "");
				session.setAttribute("state", "admin");
				response.sendRedirect("AdminPage.jsp");
			} else {
				session.setAttribute("msg", "Incorect Login ID/ password");
				response.sendRedirect("AdminLogin.jsp");
			}
		}

		// Block for
		else if (session.getAttribute("Formname").equals("NEW REGISTRATION")) {
			InterfaceBank ibank = BankFactory.getClass("Adminnewcustomer",uname);
			try {
				List<Model> newcust = ibank.display(null);
				session.setAttribute("NewCustomerList", newcust);
				response.sendRedirect("NewCustomerRegistration.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// block for viewing the pending customer registration
		else if (session.getAttribute("Formname").equals("ViewRecord")) {
			InterfaceBank ibank = BankFactory.getClass("ViewNewCustomerRecord",uname);
			try {
				Model model = new CustomerModel(
						(String) request.getParameter("cid"));
				Model list = ibank.displayrecords(model);
				Registration r = (Registration) list;
				System.out.println(r.getFname());
				session.setAttribute("c_id", request.getParameter("cid"));
				session.setAttribute("listobj", list);
				response.sendRedirect("ViewRecord.jsp");
			} catch (Exception e) {

			}
		}

		// Block for approving the customer registration
		else if (session.getAttribute("Formname").equals("ApproveNewCust")) {
			// System.out.println("ji");
			try {
				InterfaceBank interfaceBank = BankFactory
						.getClass("ApproveCustomer",uname);
				Model model = new CustomerModel(
						(String) session.getAttribute("c_id"));
				interfaceBank.update(model);
				System.out.println("Updated");
				session.setAttribute("Formname", "NEW REGISTRATION");
				response.sendRedirect("BaseController");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		// Block for rejecting the customer registration
		else if (session.getAttribute("Formname").equals("RejectNewCust")) {
			try {
				InterfaceBank ibank = BankFactory.getClass("Reject Customer",uname);
				Model model = new CustomerModel(
						(String) session.getAttribute("c_id"));
				ibank.update(model);
				System.out.println("Updated");
				session.setAttribute("Formname", "NEW REGISTRATION");
				response.sendRedirect("BaseController");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// Block for Rejected Customers Last Login
		else if (session.getAttribute("Formname").equals("RejectedCustomer")) {
			try {
				InterfaceBank interfaceBank = BankFactory
						.getClass("Reject Customer",uname);
				CustomerModel customerModel = new CustomerModel(
						(String) session.getAttribute("id"));
				interfaceBank.delete(customerModel);
				response.sendRedirect("LogOutServlet");
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("Error in Rejecting" + e.getMessage());
			}

		}
		// Block for logging out
		else if (session.getAttribute("Formname").equals("Logout")) {
			response.sendRedirect("LogOutServlet");
		} else if (session.getAttribute("Formname").equals("BankStatement")) {

			response.sendRedirect("BankStatement.jsp");

		}
		else if(session.getAttribute("Formname").equals("Transaction"))
			{
			session.setAttribute("custfname_TRANSACTION", fname);
			session.setAttribute("custlname_TRANSACTION", lname);
			session.setAttribute("custUsername",uname);
			
			TransModel mode=(TransModel)session.getAttribute("customer_trans");
			InterfaceBank ibank = BankFactory.getClass("Transaction",uname);
			try {
				String k = ibank.save(mode);
				session.setAttribute("trans_id", k);
				if (k != null) {
					
					response.sendRedirect("TransactionSuccess.jsp");
				} else {
					response.sendRedirect("TransactionError.jsp");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			}
		else if (session.getAttribute("Formname").equals("BankStatementmodule")) {
		System.out.println("Hello");
			BNKstatement obj = (BNKstatement) session
					.getAttribute("stateobject");
			 System.out.println((String) obj.getNumber());
			InterfaceBank ibank = BankFactory.getClass("BankStatement",uname);
			//System.out.println("))))");
			try {
				List<Model> bankstatementlist = ibank.display(obj);

				session.setAttribute("Liststate", bankstatementlist);
				response.sendRedirect("BankStatementView.jsp");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
