package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class CustomerIDgenerator {
	public static String customerid() {
		String id = new String();
		try {
			int flag = 1;
			while (flag == 1) {
				String custid = id();
				Connection con = BaseDao.getCon();
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery("select Customer_id from Customerinfo");
				flag = 0;
				while (rs.next()) {
					if (rs.getString(1).equals(custid)) {
						flag = 1;
					}
				}
				if (flag == 0) {
					id = custid;
				}
			}
		} catch (Exception E) {

		}
		return id;
	}

	public static String id() {
		int k = (int) (Math.random() * 1000);
		if (k < 100 && k >= 10) {
			/*StringBuffer randno = new StringBuffer();
			randno.append("R-0");
			String j = String.valueOf(k);
			randno.append(j);
			return randno.toString();*/
			return "R-0"+k;
		} else if (k < 10) {
			/*StringBuffer randno = new StringBuffer();
			randno.append("R-00");
			String j = String.valueOf(k);
			randno.append(j);
			return randno.toString();*/
			return "R-00"+k;
		} else {
			/*StringBuffer randno = new StringBuffer();
			randno.append("R-");
			String j = String.valueOf(k);
			randno.append(j);
			return randno.toString();*/
			return "R-"+k;
		}
	}
}
