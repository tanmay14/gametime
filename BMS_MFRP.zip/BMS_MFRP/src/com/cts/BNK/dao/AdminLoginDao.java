package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.BNK.model.AdminLoginModel;
import com.cts.BNK.model.Model;

public class AdminLoginDao extends BaseDao {
	public boolean login(Model basemodel) {
		AdminLoginModel adminLogin = (AdminLoginModel) basemodel;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = BaseDao.getCon();
			pstm = conn
					.prepareStatement("select * from Admin where uname =? AND password2=?");
			pstm.setString(1, adminLogin.getUserName());
			pstm.setString(2, adminLogin.getPassword());
			rs = pstm.executeQuery();
			return rs.next();

		} catch (Exception e) {

			// TODO: handle exception
			System.out.println("Error in Login" + e.getMessage());
		}
		return false;
	}
}











/*package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cts.BNK.model.AdminLoginModel;
import com.cts.BNK.model.Model;

public class AdminLoginDao extends BaseDao {
	public boolean login(Model basemodel) {
		AdminLoginModel adminLogin = (AdminLoginModel) basemodel;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = BaseDao.getCon();
			pstm = conn
					.prepareStatement("select * from Admin where uname =? AND password2=?");
			pstm.setString(1, adminLogin.getUserName());
			pstm.setString(2, adminLogin.getPassword());
			rs = pstm.executeQuery();
			return rs.next();

		} catch (Exception e) {

			// TODO: handle exception
			System.out.println("Error in Login" + e.getMessage());
		}
		return false;
	}
}
*/