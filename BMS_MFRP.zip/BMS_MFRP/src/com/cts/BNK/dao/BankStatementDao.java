package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.BNK.model.BNKstatement;
import com.cts.BNK.model.BankStatementGenerationModel;
import com.cts.BNK.model.Model;

public class BankStatementDao {
	final static List<Model> b= new ArrayList<Model>();

	public static List<Model> getB() {
		return b;
	}

	public List<Model> display(Model model) {
		
		BNKstatement bsg = (BNKstatement) model;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String s;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			con = BaseDao.getCon();
			String cid = bsg.getCustid();
			String acc = null, fname = null, lname = null;
			ps = con.prepareStatement("Select Firstname,Lastname,Accountno from Customerinfo where Customer_Id=?");
			ps.setString(1, cid);
			rs = ps.executeQuery();
			while (rs.next()) {
				acc = rs.getString(3);
				fname = rs.getString(1);
				lname = rs.getString(2);
			}
			Date d1 = sdf.parse(bsg.getFromdate());
			Date d2 = sdf.parse(bsg.getTodate());
			s = bsg.getTransactiontype();
			if (s.equalsIgnoreCase("deposit"))
				ps = con.prepareStatement("Select Transaction_Id,Transaction_type,Transaction_Date,Transaction_Amount,NewCustomerbalance from Transaction where Customer_Id=? and Transaction_Date between ? and ? and Transaction_type='Deposit'");
			else if (s.equalsIgnoreCase("withdrawal"))
				ps = con.prepareStatement("Select Transaction_Id,Transaction_type,Transaction_Date,Transaction_Amount,NewCustomerbalance from Transaction where Customer_Id=? and Transaction_Date between ? and ? and Transaction_type='Withdraw'");
			else
				ps = con.prepareStatement("Select Transaction_Id,Transaction_type,Transaction_Date,Transaction_Amount,NewCustomerbalance from Transaction where Customer_Id=? and Transaction_Date between ? and ?");
			ps.setString(1, cid);
			ps.setDate(2, new java.sql.Date(d1.getTime()));
			ps.setDate(3, new java.sql.Date(d2.getTime()));

			rs = ps.executeQuery();
			while (rs.next()) {
				BankStatementGenerationModel k = new BankStatementGenerationModel();
				k.setAccno(acc);
				k.setFname(fname);
				k.setLname(lname);
				// System.out.println(rs.getString(1));
				k.setTransactionId(rs.getString(1));
				k.setTransactiontype(rs.getString(2));
				k.setTransactionDate(rs.getString(3));
				k.setAmount(rs.getString(4));
				k.setAccountBalance(rs.getString(5));
				b.add((Model) k);
			}

		} catch (Exception E) {
			E.printStackTrace();
		}

		return b;

	}
}
