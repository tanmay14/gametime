/**
 * 
 */
package com.cts.BNK.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.BNK.model.CustomerinfoModel;
import com.cts.BNK.model.Model;
import com.cts.BNK.model.TransactionModel;

/**
 * @author 533365
 * 
 */
public class TransactionDao extends Model {
	private String TransactionID;
	private String result;
	public PreparedStatement ps = null;
	public final static Connection con = BaseDao.getCon();
	public  ResultSet rs = null;
	String t_id = null, t_type = null, app_status = null, acc_no = null;
	long t_amount , newBal;
	static TransactionModel tm = new TransactionModel();
	public  List<Model> tDaoList = new ArrayList<Model>();
	static CustomerinfoModel cim=new CustomerinfoModel();
	public static Integer Withdraw_Amount=0;
	public TransactionDao() {
		

	}

	public List<Model> display(Model model) throws Exception {

		return tDaoList;

	}
	
	public void updateCustBalance(String username,String updatedBalance)
	{
		try {
			ps = con.prepareStatement("update customerinfo set custbalance='"+updatedBalance+"'where username=?");
			ps.setString(1, username);
			int status = ps.executeUpdate();
			System.out.println("IN TRANSACTION DAO:CUSTBALANCE"+status);
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		
	}
	public void setTransactionStatus(TransactionModel to) {

		Date t_date = null;
		try {
			ps = con.prepareStatement("Select transaction_id,transaction_type,transaction_date,transaction_amount,NewCustomerbalance,approval_status,account_no from transaction where customer_id=?");
			ps.setString(1, to.getCustomer_id());
			rs = ps.executeQuery();
			while (rs.next()) {
				t_id = rs.getString(1);
				newBal = rs.getLong(3);
				t_type = rs.getString(4);
				t_date = rs.getDate(5);
				t_amount = rs.getLong(6);
				app_status = rs.getString(7);
				acc_no = rs.getString(8);

				tm.setTransactionID(t_id);
				tm.setNewBal(newBal);
				tm.setDate(t_date);
				tm.setTransactionStatus(app_status);
				tm.setAmount(t_amount);
				tm.setTransactionStatus(app_status);
				tm.setAccount_no(acc_no);
				tDaoList.add((Model) tm);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String getTransactionStatus() {
		result = tm.getTransactionStatus();
		return result;
	}

	public String getCustomerId(String username) {
		String cust_id = "";
		try {
			ps = con.prepareStatement("Select customer_id from customerinfo where username=?");
			
			System.out.println("\tuser name : " + username);
			
			ps.setString(1, username);
			rs = ps.executeQuery();
			while (rs.next()) {
				cust_id = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!cust_id.equals(""))
			return cust_id;
		else
			return null;
	}
	
	public String getCustBal(String custid)
	{
		String bal="";
		int status;
		try
		{
			
		ps=con.prepareStatement("Update customerinfo set custbalance='"+TransDao.bal+"'where Customer_id=?");
			ps.setString(1, custid);
			status=ps.executeUpdate();
			System.out.println("IN TRANSACTIONDAO:UPDATE"+status);
//		rs.next();
//				bal=rs.getString(3);
//				System.out.println("Balance "+bal);
			}
			
		
		catch(SQLException e)
		{
			
		}
		
			return TransDao.bal;
		
	}
	
	
	public String getAccHolderName(String username)
	{
		String fname="",lname="";
		try{
			ps=con.prepareStatement("Select firstname,lastname from customerinfo where username=?");
			ps.setString(1, username);
			rs=ps.executeQuery();
			while(rs.next())
			{
				fname=rs.getString(2);
				lname=rs.getString(3);
				
			}	
		}
		catch(SQLException e)
		{
			
		}
		if(!(fname.equals("") && (lname.equals(""))))
		return fname+" "+lname;
		else
			return null;
	}
	
	public String getAccType(String username)
	{
		String acctype="",ida="";
		try{
			ps=con.prepareStatement("Select accounttype from customerinfo where username=?");
			ps.setString(1, username);
			rs=ps.executeQuery();
			while(rs.next())
			{
				acctype=rs.getString(19);
				
				
			}	
		}
		catch(SQLException e)
		{
			
		}
		if(!(acctype.equals("")))
		return acctype;
		else
			return null;	
		
	}
	public CustomerinfoModel getAllValues(String username)
	{
		System.out.println("transaction dao started " + username);
		rs=null;
		String id="";
		try{
			System.out.println("%%%%%%%%%%");
			ps=con.prepareStatement("Select * from customerinfo where username=?");
			ps.setString(1, username);
			System.out.println("^^^^^^^^^");
			rs=ps.executeQuery();
			System.out.println(" hhh"+ rs);


			    rs.next();
				
				
				cim.setCustomer_id(rs.getString(1));
				//System.out.println(rs.getString(1));
				cim.setFirstname(rs.getString(2));
				//System.out.println(rs.getString(2));
				cim.setLastname(rs.getString(3));
				//System.out.println(" hhh"+ rs.getString(3));
				
				//System.out.println(rs.getString(34));
				cim.setUsername(rs.getString(4));
				cim.setGuardiantype(rs.getString(6));
				cim.setGuardianname(rs.getString(7));
				cim.setAddress(rs.getString(8));
				cim.setCitizenship(rs.getString(9));
				cim.setCountry(rs.getString(10));
				cim.setState(rs.getString(11));
				cim.setCountryid(rs.getString(12));
				cim.setEmail(rs.getString(13));
				cim.setGender(rs.getString(14));
				cim.setMaritalstatus(rs.getString(15));
				cim.setContactnumber(rs.getString(16));
				cim.setRegistrationdate(rs.getDate(17));
				cim.setDob(rs.getDate(18));
				cim.setAccounttype(rs.getString(19));
				cim.setInitialdepositamount(rs.getString(21));
				cim.setBranchname(rs.getString(22));
				cim.setIfsc(rs.getString(23));
				cim.setCitizenstatus(rs.getString(24));
				cim.setPannumber(rs.getString(25));
				cim.setIdtype(rs.getString(26));
				cim.setIdnumber(rs.getString(27));
				cim.setRefname(rs.getString(28));
				cim.setRefaccno(rs.getString(29));
				cim.setRefadd(rs.getString(30));
				cim.setInterestrate(rs.getString(20));
				cim.setAvtivationsdate(rs.getDate(31));
				cim.setApprovrestatus(rs.getString(32));
				cim.setAccountno(rs.getString(33));
				cim.setCustbalance(rs.getString(34));
				System.out.println("^&^^&^&^&^^"+rs.getString(34));
			//}	
		}
		catch(SQLException e)
		{
			
		}	
		//if(cim!=null)
		return cim;
//		else 
//			return null;
		
	}
}
