package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cts.BNK.model.CustomerModel;
import com.cts.BNK.model.Model;

public class RejectCustomerDao {

	// Updating status to "NO"
	public Model update(Model model) {
		CustomerModel customerModel = (CustomerModel) model;
		Connection conn = null;
		conn = BaseDao.getCon();
		String sql = "update Customerinfo set Approvestatus='no'where Customer_id=? ";
		PreparedStatement pstm = null;
		try {
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, customerModel.getUsername());
			pstm.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	// Deleting the record from Database
	public Model delete(Model model) {
		CustomerModel customerModel = (CustomerModel) model;
		Connection conn = null;
		conn = BaseDao.getCon();
		String sql = "delete from Customerinfo where Customer_id=? ";
		PreparedStatement pstm = null;
		try {
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, customerModel.getUsername());
			pstm.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}
}
