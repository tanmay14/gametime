package com.cts.BNK.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.BNK.model.CustomerLoginModel;
import com.cts.BNK.model.Model;

public class CustomerLoginDao extends BaseDao {
	
	static String fname,lname;
//	public String getFname(String username)
//	{
//		Connection conn = null;
//		PreparedStatement pstm = null;
//		ResultSet rs = null;
//		try {
//			conn = BaseDao.getCon();
//			pstm = conn
//					.prepareStatement("select * from customerinfo where (UserName =? OR Customer_id=?)AND password2=?");
//			pstm.setString(1, loginModel.getUsername());
//			pstm.setString(2, loginModel.getUsername());
//		}
//		catch(SQLException e)
//		{
//			e.printStackTrace();
//		}
//		
//	}
	
	
	public Model login(Model basemodel) {
		CustomerLoginModel loginModel = (CustomerLoginModel) basemodel;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = BaseDao.getCon();
			pstm = conn
					.prepareStatement("select * from customerinfo where UserName =? AND password2=?");
					//.prepareStatement("select * from customerinfo where (UserName =? OR Customer_id=?)AND password2=?");
			pstm.setString(1, loginModel.getUsername());
			//pstm.setString(2, loginModel.getUsername());
			pstm.setString(2, loginModel.getPassword());
			
			rs = pstm.executeQuery();
			if (rs.next()) {
				loginModel.setStatus(rs.getString("Approvestatus"));
				loginModel.setAccountno(rs.getString("Accountno"));
				loginModel.setFirstname(rs.getString("firstname"));
				loginModel.setLastname(rs.getString("lastname"));
				fname=rs.getString("firstname");
				lname=rs.getString("lastname");
				System.out.println("IN CUSTOMERLOGINDAO: fname"+fname);
				System.out.println("IN CUSTOMERLOGINDAO: lname"+lname);
				
				return loginModel;
			} else {
				return null;
			}

		} catch (Exception e) {

			// TODO: handle exception
			System.out.println("Error in Login" + e.getMessage());
		}
		return null;
	}
}
