package com.cts.BNK.model;

public class Model {

}
