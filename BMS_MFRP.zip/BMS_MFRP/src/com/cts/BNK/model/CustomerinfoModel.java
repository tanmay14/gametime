package com.cts.BNK.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.BNK.dao.BaseDao;
import com.cts.BNK.model.CustomerinfoModel;
import com.cts.BNK.model.Model;
import com.cts.BNK.model.TransactionModel;

public class CustomerinfoModel extends Model{
	
	
	private String TransactionID;
	private String result;
	public PreparedStatement ps = null;
	public final static Connection con = BaseDao.getCon();
	public  ResultSet rs = null;
	String t_id = null, t_type = null, app_status = null, acc_no = null;
	long t_amount , newBal;
	static TransactionModel tm = new TransactionModel();
	public  List<Model> tDaoList = new ArrayList<Model>();

	
	private String Customer_id;
	private String firstname;
	private String lastname;
	private String username;
	private String password;
	private String guardiantype;
	private String guardianname;
	private String address;
	private String citizenship;
	private String country;
	private String state;
	private String countryid;
	private String email;
	private String gender;
	private String maritalstatus;
	private String contactnumber;
	private Date registrationdate;
	private Date dob;
	private String accounttype;
	private String initialdepositamount;
	private String branchname;
	private String ifsc;
	private String citizenstatus;
	private String pannumber;
	private String idtype;
	private String idnumber;
	private String refname;
	private String refaccno;
	private String refadd;
	private String interestrate;
	private Date avtivationsdate;
	private String approvrestatus;
	private String accountno;
	private String custbalance;
	public CustomerinfoModel()
	{
		
	}
	
	public String updateCustBalance(String username,String updatedBalance)
	{
		try {
			ps = con.prepareStatement("update customerinfo set custbalance='"+updatedBalance+"'where username=?");
			ps.setString(1, username);
			int status = ps.executeUpdate();
			System.out.println("IN CUSTOMERINFOMODEL"+ status);
		}
		catch(SQLException sqe)
		{
			sqe.printStackTrace();
		}
		return "";
		
	}
	
	public CustomerinfoModel getAllValues(String username)
	{
		System.out.println("transaction dao started " + username);
		CustomerinfoModel cim=new CustomerinfoModel();
		String id="";
		try{
			ps=con.prepareStatement("Select Customer_id,firstname,lastname,username,guardiantype,guardianname,address,citizenship,country,state,countryid,email,gender,maritalstatus,contactnumber,registrationdate,dob,accounttype,initialdepositamount,branchname,ifsc,citizenstatus,pannumber,idtype,idnumber,refname,refaccno,refadd,interestrate,avtivationsdate,approvrestatus,accountno,custbalance from customerinfo where username=?");
			ps.setString(1, username);
			
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				id=rs.getString(1);
				System.out.println("@@@@@@"+id);
				cim.setCustomer_id(rs.getString(1));
				System.out.println("*************"+cim.getCustomer_id());
				cim.setFirstname(rs.getString(2));
				cim.setLastname(rs.getString(3));
				cim.setUsername(rs.getString(4));
				cim.setGuardiantype(rs.getString(6));
				cim.setGuardianname(rs.getString(7));
				cim.setAddress(rs.getString(8));
				cim.setCitizenship(rs.getString(9));
				cim.setCountry(rs.getString(10));
				cim.setState(rs.getString(11));
				cim.setCountryid(rs.getString(12));
				cim.setEmail(rs.getString(13));
				cim.setGender(rs.getString(14));
				cim.setMaritalstatus(rs.getString(15));
				cim.setContactnumber(rs.getString(16));
				cim.setRegistrationdate(rs.getDate(17));
				cim.setDob(rs.getDate(18));
				cim.setAccounttype(rs.getString(19));
				cim.setInitialdepositamount(rs.getString(20));
				cim.setBranchname(rs.getString(21));
				cim.setIfsc(rs.getString(22));
				cim.setCitizenstatus(rs.getString(23));
				cim.setPannumber(rs.getString(24));
				cim.setIdtype(rs.getString(25));
				cim.setIdnumber(rs.getString(26));
				cim.setRefname(rs.getString(27));
				cim.setRefaccno(rs.getString(28));
				cim.setRefadd(rs.getString(29));
				cim.setInterestrate(rs.getString(30));
				cim.setAvtivationsdate(rs.getDate(31));
				cim.setApprovrestatus(rs.getString(32));
				cim.setAccountno(rs.getString(33));
				cim.setCustbalance(rs.getString(34));
				
			}	
		}
		catch(SQLException e)
		{
			
		}	
		//if(cim!=null)
		return cim;
//		else 
//			return null;
		
	}
	public String getCustomer_id() {
		return Customer_id;
	}
	public void setCustomer_id(String customer_id) {
		Customer_id = customer_id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGuardiantype() {
		return guardiantype;
	}
	public void setGuardiantype(String guardiantype) {
		this.guardiantype = guardiantype;
	}
	public String getGuardianname() {
		return guardianname;
	}
	public void setGuardianname(String guardianname) {
		this.guardianname = guardianname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCitizenship() {
		return citizenship;
	}
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountryid() {
		return countryid;
	}
	public void setCountryid(String countryid) {
		this.countryid = countryid;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMaritalstatus() {
		return maritalstatus;
	}
	public void setMaritalstatus(String maritalstatus) {
		this.maritalstatus = maritalstatus;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public Date getRegistrationdate() {
		return registrationdate;
	}
	public void setRegistrationdate(Date registrationdate) {
		this.registrationdate = registrationdate;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public String getInitialdepositamount() {
		return initialdepositamount;
	}
	public void setInitialdepositamount(String initialdepositamount) {
		this.initialdepositamount = initialdepositamount;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getCitizenstatus() {
		return citizenstatus;
	}
	public void setCitizenstatus(String citizenstatus) {
		this.citizenstatus = citizenstatus;
	}
	public String getPannumber() {
		return pannumber;
	}
	public void setPannumber(String pannumber) {
		this.pannumber = pannumber;
	}
	public String getIdtype() {
		return idtype;
	}
	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}
	public String getIdnumber() {
		return idnumber;
	}
	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}
	public String getRefname() {
		return refname;
	}
	public void setRefname(String refname) {
		this.refname = refname;
	}
	public String getRefaccno() {
		return refaccno;
	}
	public void setRefaccno(String refaccno) {
		this.refaccno = refaccno;
	}
	public String getRefadd() {
		return refadd;
	}
	public void setRefadd(String refadd) {
		this.refadd = refadd;
	}
	public String getInterestrate() {
		return interestrate;
	}
	public void setInterestrate(String interestrate) {
		this.interestrate = interestrate;
	}
	public Date getAvtivationsdate() {
		return avtivationsdate;
	}
	public void setAvtivationsdate(Date avtivationsdate) {
		this.avtivationsdate = avtivationsdate;
	}
	public String getApprovrestatus() {
		return approvrestatus;
	}
	public void setApprovrestatus(String approvrestatus) {
		this.approvrestatus = approvrestatus;
	}
	public String getAccountno() {
		return accountno;
	}
	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}
	public String getCustbalance() {
		return custbalance;
	}
	public void setCustbalance(String custbalance) {
		this.custbalance = custbalance;
	}
	
	
	
}
