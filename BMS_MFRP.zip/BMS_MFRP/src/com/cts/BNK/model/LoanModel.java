package com.cts.BNK.model;

public class LoanModel extends Model{

	
	private String loanType;
	private String loanAmount;
	private String loanApplyDate;
	private String issueDate;
	private String rateOfInterest;
	private String dateOfLoan;
	private String courseFee;
	private String  course;
	private String fatherName;
	private String fatherOcupation;
	private String fatherTotalExp;
	private String fatherExpCurrent;
	private String rationCard;
	private String familyAnnualIncome;
	private String companyName;
	private String designation;
	private String totalExp;
	private String expCurrent;
	public String getLoanType() {
		return loanType;
	}
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	public String getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(String loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getLoanApplyDate() {
		return loanApplyDate;
	}
	public void setLoanApplyDate(String loanApplyDate) {
		this.loanApplyDate = loanApplyDate;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(String rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public String getDateOfLoan() {
		return dateOfLoan;
	}
	public void setDateOfLoan(String dateOfLoan) {
		this.dateOfLoan = dateOfLoan;
	}
	public String getCourseFee() {
		return courseFee;
	}
	public void setCourseFee(String courseFee) {
		this.courseFee = courseFee;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public String getFatherOcupation() {
		return fatherOcupation;
	}
	public void setFatherOcupation(String fatherOcupation) {
		this.fatherOcupation = fatherOcupation;
	}
	public String getFatherTotalExp() {
		return fatherTotalExp;
	}
	public void setFatherTotalExp(String fatherTotalExp) {
		this.fatherTotalExp = fatherTotalExp;
	}
	public String getFatherExpCurrent() {
		return fatherExpCurrent;
	}
	public void setFatherExpCurrent(String fatherExpCurrent) {
		this.fatherExpCurrent = fatherExpCurrent;
	}
	public String getRationCard() {
		return rationCard;
	}
	public void setRationCard(String rationCard) {
		this.rationCard = rationCard;
	}
	public String getFamilyAnnualIncome() {
		return familyAnnualIncome;
	}
	public void setFamilyAnnualIncome(String familyAnnualIncome) {
		this.familyAnnualIncome = familyAnnualIncome;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getTotalExp() {
		return totalExp;
	}
	public void setTotalExp(String totalExp) {
		this.totalExp = totalExp;
	}
	public String getExpCurrent() {
		return expCurrent;
	}
	public void setExpCurrent(String expCurrent) {
		this.expCurrent = expCurrent;
	}
	
	
	

}
