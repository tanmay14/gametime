package com.cts.BNK.model;

public class TransModel extends Model{
private String custId;
private String accHolder;
private String transDate;
private String userName;
private String accNumber;
private String money;
private String money11;
private String transactiontype1;
private String rembal;
public String getCustId() {
	return custId;
}
public void setCustId(String custId) {
	this.custId = custId;
}
public String getAccHolder() {
	return accHolder;
}
public void setAccHolder(String accHolder) {
	this.accHolder = accHolder;
}
public String getTransDate() {
	return transDate;
}
public void setTransDate(String transDate) {
	this.transDate = transDate;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getAccNumber() {
	return accNumber;
}
public void setAccNumber(String accNumber) {
	this.accNumber = accNumber;
}
public String getMoney() {
	return money;
}
public void setMoney(String money) {
	this.money = money;
}
public String getMoney11() {
	return money11;
}
public void setMoney11(String money11) {
	this.money11 = money11;
}
public String getTransactiontype1() {
	return transactiontype1;
}
public void setTransactiontype1(String transactiontype1) {
	this.transactiontype1 = transactiontype1;
}
public String getRembal() {
	return rembal;
}
public void setRembal(String rembal) {
	this.rembal = rembal;
}


}
