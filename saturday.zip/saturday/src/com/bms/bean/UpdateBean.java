package com.bms.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UpdateBean {
	private String Customer_Id;
	private String Name;
	private String Account_Number;
	private String Country;
	private String State;
	private String Gender;
	private String DOB;
	private String Registration_Date;
	private String Bank_Name;
	private String Branch_Name;
	private String IFSC_Code;
	private String Identification_proof_type;
	private String Identification_doc_number;
	private String Reference_account_holder_name;
	private String Reference_account_holder_account_number;
	private String Reference_account_holder_address;
	private String Address;
	private String AlternateAddress;
	private long Contact_number;
	private long AlternateContact_number;
	private String Mail_Id;
	private String Marital_Status;
	private String Account_Type;
	private String Citizenship;
	private String Citizen_Status;
	private String Guardian_Type;
	private String Guardian_Name;
	private String Loan_Issue_Date;
	private String Loan_Amount;
	private String Loan_Type;
	private String Loan_Status;

	public String getCustomer_Id() {
		return Customer_Id;
	}

	public void setCustomer_Id(String customer_Id) {
		Customer_Id = customer_Id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAccount_Number() {
		return Account_Number;
	}

	public void setAccount_Number(String account_Number) {
		Account_Number = account_Number;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) throws ParseException {
		DOB = dOB;
		Date curr = new Date();
		Calendar c1 = Calendar.getInstance();
		c1.setTime(curr);
		Long l = c1.getTimeInMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date d2 = sdf.parse(dOB);
		c1.setTime(d2);
		Long l2 = c1.getTimeInMillis();
		long age = ((l - l2) / (1000));
		age /= 3600;
		age /= 24;
		age /= 365;
		if (age < 18)
			this.Citizen_Status = "minor";
		else if (age >= 18 && age < 60)
			this.Citizen_Status = "normal";
		else
			this.Citizen_Status = "senior";

	}

	public String getRegistration_Date() {
		return Registration_Date;
	}

	public void setRegistration_Date(String registration_Date) {
		Registration_Date = registration_Date;
	}

	public String getBank_Name() {
		return Bank_Name;
	}

	public void setBank_Name(String bank_Name) {
		Bank_Name = bank_Name;
	}

	public String getBranch_Name() {
		return Branch_Name;
	}

	public void setBranch_Name(String branch_Name) {
		Branch_Name = branch_Name;
	}

	public String getIFSC_Code() {
		return IFSC_Code;
	}

	public void setIFSC_Code(String iFSC_Code) {
		IFSC_Code = iFSC_Code;
	}

	public String getIdentification_proof_type() {
		return Identification_proof_type;
	}

	public void setIdentification_proof_type(String identification_proof_type) {
		Identification_proof_type = identification_proof_type;
	}

	public String getIdentification_doc_number() {
		return Identification_doc_number;
	}

	public void setIdentification_doc_number(String identification_doc_number) {
		Identification_doc_number = identification_doc_number;
	}

	public String getReference_account_holder_name() {
		return Reference_account_holder_name;
	}

	public void setReference_account_holder_name(
			String reference_account_holder_name) {
		Reference_account_holder_name = reference_account_holder_name;
	}

	public String getReference_account_holder_account_number() {
		return Reference_account_holder_account_number;
	}

	public void setReference_account_holder_account_number(
			String reference_account_holder_account_number) {
		Reference_account_holder_account_number = reference_account_holder_account_number;
	}

	public String getReference_account_holder_address() {
		return Reference_account_holder_address;
	}

	public void setReference_account_holder_address(
			String reference_account_holder_address) {
		Reference_account_holder_address = reference_account_holder_address;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public long getContact_number() {
		return Contact_number;
	}

	public void setContact_number(long contact_number) {
		Contact_number = contact_number;
	}

	public String getMail_Id() {
		return Mail_Id;
	}

	public void setMail_Id(String mail_Id) {
		Mail_Id = mail_Id;
	}

	public String getMarital_Status() {
		return Marital_Status;
	}

	public void setMarital_Status(String marital_Status) {
		Marital_Status = marital_Status;
	}

	public String getAccount_Type() {
		return Account_Type;
	}

	public void setAccount_Type(String account_Type) {
		Account_Type = account_Type;
	}

	public String getCitizenship() {
		return Citizenship;
	}

	public void setCitizenship(String citizenship) {
		Citizenship = citizenship;
	}

	public String getCitizen_Status() {
		return Citizen_Status;
	}

	public String getGuardian_Type() {
		return Guardian_Type;
	}

	public void setGuardian_Type(String guardian_Type) {
		Guardian_Type = guardian_Type;
	}

	public String getGuardian_Name() {
		return Guardian_Name;
	}

	public void setGuardian_Name(String guardian_Name) {
		Guardian_Name = guardian_Name;
	}

	public String getLoan_Issue_Date() {
		return Loan_Issue_Date;
	}

	public void setLoan_Issue_Date(String loan_Issue_Date) {
		Loan_Issue_Date = loan_Issue_Date;
	}

	public String getLoan_Amount() {
		return Loan_Amount;
	}

	public void setLoan_Amount(String loan_Amount) {
		Loan_Amount = loan_Amount;
	}

	public String getLoan_Type() {
		return Loan_Type;
	}

	public void setLoan_Type(String loan_Type) {
		Loan_Type = loan_Type;
	}

	public String getLoan_Status() {
		return Loan_Status;
	}

	public void setLoan_Status(String loan_Status) {
		Loan_Status = loan_Status;
	}

	public String getAlternateAddress() {
		return AlternateAddress;
	}

	public void setAlternateAddress(String Alternateaddress) {
		AlternateAddress = Alternateaddress;
	}

	public long getAlternateContact_number() {
		return AlternateContact_number;
	}

	public void setAlternateContact_number(long Alternatecontact_number) {
		AlternateContact_number = Alternatecontact_number;
	}

}
