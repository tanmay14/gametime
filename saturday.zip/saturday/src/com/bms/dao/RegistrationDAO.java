package com.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.RegistrationBean;
import com.bms.util.PropertyUtil;

public class RegistrationDAO {
	Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;
	PreparedStatement prep = null;// taking values from user at runtime
	PreparedStatement prepacc = null;
	PreparedStatement prepid = null;
	PreparedStatement prepLog = null;
	PropertyUtil util = new PropertyUtil();
	public static Logger LOG = Logger.getLogger(RegistrationDAO.class);

	public boolean insertUser(RegistrationBean user)
			throws ClassNotFoundException, SQLException, ParseException,
			BusinessException {
		LOG.error("Inside RegistrationDAO class - insertuser method ");
		boolean flag = false;
		try {
			conn = util.connections();
			String sql = "insert into Customer_Details(Customer_Id,Name,UserName,Guardian_Name,"
					+ "Guardian_Type,Address,AlternateAddress,Country_Id,"
					+ "Email_Address,Gender,Marital_Status,Contact_Number,AlternateContact_Number,Date_Of_Birth,Citizen_Status,Citizenship)"
					+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			prep = conn.prepareStatement(sql);
			String s = generateCustId();
			user.setCustomer_Id(s);
			prep.setString(1, s);
			prep.setString(2, user.getName());
			prep.setString(3, user.getUserName());
			prep.setString(4, user.getGuardian_Name());
			prep.setString(5, user.getGuardian_Type());
			prep.setString(6, user.getAddress());
			prep.setString(7, user.getAlternateAddress());
			prep.setString(8,
					util.generateCountryId(user.getCountry(), user.getState()));
			prep.setString(9, user.getEmail_Address());
			prep.setString(10, user.getGender());
			prep.setString(11, user.getMarital_Status());
			prep.setLong(12, user.getContact_No());
			prep.setLong(13, user.getAlternateContact_No());
			prep.setDate(14, util.utilDateToSqlDate(user.getDate_Of_Birth()));
			prep.setString(15, user.getCitizen_status());
			prep.setString(16, user.getCitizenship());
			LOG.error(" RegistrationDao after creating prepare statement for customer_details table");
			String log = "insert into login_table(Customer_Id,UserName,Password)"
					+ "values(?,?,?)";
			prepLog = conn.prepareStatement(log);
			prepLog.setString(1, s);
			prepLog.setString(2, user.getUserName());
			prepLog.setString(3, user.getPassword());
			String acc = "insert into Account_Info(Customer_Id,Account_Type,Account_Number,"
					+ "Registration_Date,Initial_Deposit_Amount,IFSC_Code,Activation_Date,Account_Balance,reference_acc_number) "
					+ "values(?,?,?,?,?,?,?,?,?)";
			String account_no = generate_acc_no();
			user.setAccount_number(account_no);
			String ifsccode = util.generateIFSC(user.getBranch_name());
			prepacc = conn.prepareStatement(acc);
			prepacc.setString(1, s);
			prepacc.setString(2, user.getAccount_type());
			prepacc.setString(3, account_no);
			prepacc.setDate(4, util.utilDateToSqlDate(user.getRegdate()));
			prepacc.setDouble(5, user.getInitial_deposit_amount());
			prepacc.setString(6, ifsccode);
			prepacc.setDate(7, generateActivation(user.getRegdate()));
			prepacc.setDouble(8, user.getInitial_deposit_amount());
			prepacc.setString(9, user.getRef_acc_holder_no());
			String id = "insert into identification(Customer_Id,IdentificationProof_Type,IdentificationDocument_Number)"
					+ " values(?,?,?)";
			prepid = conn.prepareStatement(id);
			prepid.setString(1, s);
			prepid.setString(2, user.getIdentificationProof_Type());
			prepid.setString(3, user.getIdentificationDocument_Number());
			if (prepLog.executeUpdate() > 0)
				if (prep.executeUpdate() > 0)
					if (prepacc.executeUpdate() > 0)
						if (prepid.executeUpdate() > 0)
							flag = true;
		} catch (Exception e) {
			LOG.error("exception in  inserting values in tables "
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			if (prepid != null)
				prepid.close();
			if (prepacc != null)
				prepacc.close();
			if (prep != null)
				prep.close();
			if (prepLog != null)
				prepLog.close();
		}
		return flag;
	}

	private java.sql.Date generateActivation(String regdate)
			throws ParseException {
		LOG.info("inside RegistrationDao generateactivationdate");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date d = sdf.parse(regdate);
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		c.add(Calendar.DATE, 05);
		java.util.Date d2 = c.getTime();
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
		String s2 = sdf1.format(d2);
		java.util.Date dn = sdf1.parse(s2);
		java.sql.Date sqlDate = new java.sql.Date(dn.getTime());
		return sqlDate;
	}

	private String generateCustId() throws SQLException {
		LOG.info("Inside RegistrationDao,generate customer id()");
		StringBuffer sb = new StringBuffer();
		try {
			conn = util.connections();
			String sql = "select count(*) from login_table";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			String s = "";
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			if (num > 0) {
				sql = "select max(Customer_id) from login_table ";
				rs = stmt.executeQuery(sql);
				if (rs.next())
					s = rs.getString(1);
				sb.append(s.substring(0, 1));
				long l = Long.valueOf((String) s.substring(1, s.length()));
				l = l + 1;
				sb.append(String.valueOf(l));
			} else
				sb.append("R417100");
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return sb.toString();
	}

	private String generate_acc_no() throws ClassNotFoundException,
			SQLException {
		LOG.info("Inside RegistrationDao,generate account number()");
		StringBuffer sb = new StringBuffer();
		try {
			conn = util.connections();
			String sql = "select count(*) Account_Info";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			String s = "";
			int num = 0;
			if (rs.next()) {
				num = rs.getInt(1);
			}
			if (num >= 1) {
				sql = "select max(Account_Number) from Account_Info ";
				rs = stmt.executeQuery(sql);
				if (rs.next())
					s = rs.getString(1);
				sb.append(s.substring(0, 9));
				long l = Long.valueOf((String) s.substring(9, s.length()));
				l = l + 1;
				sb.append(String.valueOf(l));
			} else
				sb.append("2000000001000000");
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return sb.toString();
	}

	public int validUserName(String uname) throws SQLException {
		LOG.info("inside  RegistrationDao valid user name from database");
		int n = 0;
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String query = "Select count(*) from customer_details where UserName like '"
					+ uname + "'";
			rs = stmt.executeQuery(query);
			if (rs.next())
				n = rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return n;
	}

	public int validDocNo(String identificationDocument_Number)
			throws SQLException {
		LOG.info("inside valid identification document no from database");
		int n = 0;
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String query = "Select count(*) from identification where IdentificationDocument_Number like '"
					+ identificationDocument_Number + "'";
			rs = stmt.executeQuery(query);
			if (rs.next())
				n = rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return n;
	}

	public int valideMail(String email) throws SQLException {
		LOG.info("inside valid identification document no from database");
		int n = 0;
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String query = "Select count(*) from customer_details where Email_Address like '"
					+ email + "'";
			rs = stmt.executeQuery(query);
			if (rs.next())
				n = rs.getInt(1);
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return n;
	}

	private String genIden() throws SQLException {

		StringBuffer sb = new StringBuffer();
		int n = 0;
		String query2 = "";
		try {
			conn = util.connections();
			stmt = conn.createStatement();
			String query1 = "select count(*) from Identification where IdentificationDocument_Number like 'IDE%'";
			rs = stmt.executeQuery(query1);
			if (rs.next())
				n = rs.getInt(1);
			if (n >= 1) {
				query2 = "select max(IdentificationDocument_Number) from Identification where IdentificationDocument_Number like 'IDE%'";
				rs = stmt.executeQuery(query2);
				if (rs.next()) {
					String customer = rs.getString(1);
					String k = customer.substring(3);
					int i = Integer.parseInt(k);
					i++;
					k = String.valueOf(i);
					sb.append("IDE");
					sb.append(k);
				} else {
					sb.append("IDE000000001");
				}
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return sb.toString();
	}

	private String getToday() {
		String date = "";
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		date = sdf.format(d);
		return date;
	}

}
