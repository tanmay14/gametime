package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.UpdateBean;
import com.bms.bo.UpdateBO;

public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(UpdateController.class);
	UpdateBean user = null;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		LOG.info("inside Update controller");
		user = new UpdateBean();
		HttpSession session = request.getSession(true);
		if (session.getAttribute("Customer_Id") == null) {
			response.sendRedirect("Login.jsp");
		}
		String s1 = (String) session.getAttribute("Customer_Id");
		user.setCustomer_Id(s1);
		try {
			user.setAccount_Number(request.getParameter("Account_Number"));
			UpdateBO updbo = new UpdateBO();
			if (request.getParameter("Name").isEmpty())
				throw new BusinessException("Name cannot be blank");
			else
				user.setName(request.getParameter("Name"));
			if (request.getParameter("Country").isEmpty())
				throw new BusinessException("Country cannot be blank");
			else
				user.setCountry(request.getParameter("Country"));
			if (request.getParameter("State").isEmpty())
				throw new BusinessException("State cannot be blank");
			else
				user.setState(request.getParameter("State"));
			if (request.getParameter("Gender").isEmpty())
				throw new BusinessException("Gender cannot be blank");
			else
				user.setGender(request.getParameter("Gender"));
			if (request.getParameter("DOB").isEmpty()) {
				throw new BusinessException("DOB cannot be blank");
			} else
				user.setDOB(request.getParameter("DOB"));
			user.setRegistration_Date(request.getParameter("Registration_Date"));
			user.setBranch_Name(request.getParameter("Branch_Name"));
			if (request.getParameter("Identification_proof_type").isEmpty())
				throw new BusinessException(
						"Identification_proof_type cannot be empty");
			else
				user.setIdentification_proof_type(request
						.getParameter("Identification_proof_type"));
			if (request.getParameter("Identification_doc_number").isEmpty())
				throw new BusinessException(
						"Identification_doc_number cannot be empty");
			else
				user.setIdentification_doc_number(request
						.getParameter("Identification_doc_number"));

			if (request.getParameter("Reference_account_holder_address")
					.isEmpty())
				throw new BusinessException(
						"Reference_account_holder_address cannot be blank");
			else
				user.setReference_account_holder_address(request
						.getParameter("Reference_account_holder_address"));

			if (request.getParameter("Reference_account_holder_name").isEmpty())
				throw new BusinessException(
						"Reference_account_holder_name cannot be blank");
			else
				user.setReference_account_holder_name(request
						.getParameter("Reference_account_holder_name"));

			if (!request
					.getParameter("Reference_account_holder_account_number")
					.isEmpty())
				user.setReference_account_holder_account_number(request
						.getParameter("Reference_account_holder_account_number"));
			else
				throw new BusinessException(
						"Reference_account_holder_account_number cannot be blank");
			if (request.getParameter("Address").trim().equalsIgnoreCase(""))
				throw new BusinessException("Address cannot be empty");
			else
				user.setAddress(request.getParameter("Address").trim());
			if (request.getParameter("Contact_number").isEmpty())
				throw new BusinessException("Contact_number cannot be empty");
			else
				user.setContact_number(Long.parseLong((request
						.getParameter("Contact_number"))));

			if (request.getParameter("AlternateAddress").trim()
					.equalsIgnoreCase(""))
				throw new BusinessException("Address cannot be empty");
			else
				user.setAlternateAddress(request.getParameter(
						"AlternateAddress").trim());
			if (request.getParameter("AlternateContact_number").isEmpty())
				throw new BusinessException("Contact_number cannot be empty");
			else
				user.setAlternateContact_number(Long.parseLong((request
						.getParameter("AlternateContact_number"))));

			if (request.getParameter("Mail_Id").isEmpty())
				throw new BusinessException("Mail_Id cannot be empty");
			else
				user.setMail_Id(request.getParameter("Mail_Id"));
			if (request.getParameter("Marital_Status").isEmpty())
				throw new BusinessException("Marital_Status cannot be empty");
			else
				user.setMarital_Status(request.getParameter("Marital_Status"));
			if (request.getParameter("Citizenship").isEmpty())
				throw new BusinessException("Citizenship cannot be empty");
			else
				user.setCitizenship(request.getParameter("Citizenship"));
			if (request.getParameter("Guardian_Type").isEmpty())
				throw new BusinessException("Guardian_Type cannot be empty");
			else
				user.setGuardian_Type(request.getParameter("Guardian_Type"));
			if (request.getParameter("Guardian_Name").isEmpty())
				throw new BusinessException("Guardian_Name cannot be empty");
			else
				user.setGuardian_Name(request.getParameter("Guardian_Name"));
			user.setLoan_Amount(request.getParameter("Loan_Amount"));
			user.setLoan_Issue_Date(request.getParameter("Loan_Issue_Date"));
			user.setLoan_Type(request.getParameter("Loan_Type"));
			user.setLoan_Status(request.getParameter("Loan_Status"));
			boolean flag = updbo.updateUser(user);
			if (flag == true) {
				request.setAttribute("Message", "update");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Update.jsp");
				dispatcher.forward(request, response);
			} else {
				request.setAttribute("Message", "Error");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Update.jsp");
				dispatcher.forward(request, response);
			}
		} catch (BusinessException e) {
			LOG.error("UpdateException" + e.getMessage());
			request.setAttribute("Message", e.getMessage());
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Update.jsp");
			dispatch.forward(request, response);
		} catch (NumberFormatException e) {
			request.setAttribute("Message", "Contact Number can only be digits");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Update.jsp");
			dispatch.forward(request, response);
		} catch (Exception e) {
			LOG.error("Exception from UPdatecontroller" + e.getMessage());
			request.setAttribute("Message", "Error");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Update.jsp");
			dispatch.forward(request, response);
		}
	}
}
