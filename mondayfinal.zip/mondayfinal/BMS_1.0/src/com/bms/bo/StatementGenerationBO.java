package com.bms.bo;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.StatementGenerationBean;
import com.bms.dao.StatementGenerationDAO;

public class StatementGenerationBO {
	public static Logger LOG = Logger.getLogger(StatementGenerationBO.class);
	private static final String COMMA_DELIMITER = ",";
	private static final String NEW_LINE_SEPARATOR = "\r\n";
	private static final String COLUMN_HEADER = "Transaction Date,Debit,Credit,Transaction Id,Amount,Cheque_Number,Description,Balance";

	public void dateValidate(String From_Date, String To_Date,
			String Transaction_Date) throws BusinessException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date from_date = null;
		try {
			from_date = sdf.parse(From_Date);
			Date to_date = null;
			to_date = sdf.parse(To_Date);
			int k = (int) ((to_date.getTime() - from_date.getTime()) / (3600 * 1000 * 24));
			if (from_date.before(to_date)) {
			} else
				throw new BusinessException("To-Date should be after From-Date");
			if (k > 365) {
				throw new BusinessException(
						"Difference between To-Date and From-Date must not be greater than 12 months");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public String[] checkTransaction(StatementGenerationBean bean)
			throws BusinessException, ParseException, SQLException,
			ClassNotFoundException {
		dateValidate(bean.getFrom_Date(), bean.getTo_Date(),
				bean.getTransaction_Date());
		StatementGenerationDAO dao = new StatementGenerationDAO();
		String check[] = dao.getNumberOfTran(bean);
		return check;
	}

	public boolean getListOfTran(StatementGenerationBean bean)
			throws SQLException, ParseException, BusinessException,
			ClassNotFoundException {
		boolean b = false;
		LOG.info("inside Statement Generation BO");
		StatementGenerationDAO dao = new StatementGenerationDAO();
		ArrayList<StatementGenerationBean> list = dao.transactionDownload(bean);
		String CustName = dao.getCustName(bean.getCustomer_Id());
		String AccNo = dao.getAccNo(bean.getCustomer_Id());
		FileWriter fileWriter = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Date from_date = sdf.parse(bean.getFrom_Date());
			Date to_date = sdf.parse(bean.getTo_Date());
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd.MM.yyyy");
			String FromDate = sdf1.format(from_date);
			String ToDate = sdf1.format(to_date);
			LOG.info("inside Statement Generation BO after converting string to sql date");
			String fileName = "" + bean.getCustomer_Id() + "-" + FromDate + "-"
					+ ToDate + "";
			String fileAddress = System.getProperty("user.home") + "/"
					+ fileName + ".txt";
			fileWriter = new FileWriter(fileAddress);
			String FILEHEADER = "Customer_Name: " + CustName
					+ ", Account Number: " + AccNo + ", Start Date: "
					+ bean.getFrom_Date() + ", End Date: " + bean.getTo_Date()
					+ "";
			fileWriter.append(FILEHEADER);
			fileWriter.append(NEW_LINE_SEPARATOR);
			fileWriter.append(NEW_LINE_SEPARATOR);
			fileWriter.append(NEW_LINE_SEPARATOR);
			fileWriter.append(COLUMN_HEADER);
			fileWriter.append(NEW_LINE_SEPARATOR);
			for (StatementGenerationBean bean1 : list) {
				fileWriter.append(String.valueOf(bean1.getTransaction_Date()));
				fileWriter.append(COMMA_DELIMITER);
				if (bean1.getTransaction_Type().equalsIgnoreCase("withdrawal"))
					fileWriter.append(bean1.getTransaction_Type());
				else
					fileWriter.append("----");
				fileWriter.append(COMMA_DELIMITER);
				if (bean1.getTransaction_Type().equalsIgnoreCase("deposit"))
					fileWriter.append(bean1.getTransaction_Type());
				else
					fileWriter.append("----");
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(String.valueOf(bean1.getTransaction_Id()));
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(bean1.getAmount());
				fileWriter.append(COMMA_DELIMITER);
				if (bean1.getCheque_Number().isEmpty())
					fileWriter.append("----");
				else
					fileWriter.append(bean1.getCheque_Number());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(bean1.getDescription());
				fileWriter.append(COMMA_DELIMITER);
				fileWriter.append(bean1.getBalance());
				fileWriter.append(NEW_LINE_SEPARATOR);
				LOG.info("inside Statement Generation BO after appending in file for downloadingw");
			}
		} catch (Exception e) {
			LOG.error("Inside StatementGenerationBO exception" + e.getMessage());
		} finally {
			try {
				b = true;
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
			}
		}
		return b;
	}
}
