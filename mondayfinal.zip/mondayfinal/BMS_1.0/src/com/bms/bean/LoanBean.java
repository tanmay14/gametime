package com.bms.bean;

public class LoanBean {
	private double EMI;
	private String Custid;
	private String LoanAccNo;
	private String LoanId;
	private String LoanType;
	private double LoanAmount;
	private String LoanApplyDate;
	private String LoanIssueDate;
	private float RateOfInterest;
	private int DurationLoan;
	private double CourseFee;
	private String Course;
	private String FatherName;
	private String FatherOccupation;
	private int FatherTotalExp;
	private int FatherExpwCC;
	private String RationCard;
	private double AnnualIncome;
	private String CompanyName;
	private String Designation;
	private int TotalExp;
	private int ExpCC;
	private String GuarantorName;
	private String GuarantorAddress;
	private double GuarantorIncome;

	public String getLoanId() {
		return LoanId;
	}

	public void setLoanId(String loanId) {
		LoanId = loanId;
	}

	public String getLoanType() {
		return LoanType;
	}

	public void setLoanType(String loanType) {
		LoanType = loanType;
	}

	public double getLoanAmount() {
		return LoanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		LoanAmount = loanAmount;
	}

	public String getLoanApplyDate() {
		return LoanApplyDate;
	}

	public void setLoanApplyDate(String loanApplyDate) {
		LoanApplyDate = loanApplyDate;
	}

	public String getLoanIssueDate() {
		return LoanIssueDate;
	}

	public void setLoanIssueDate(String loanIssueDate) {
		LoanIssueDate = loanIssueDate;
	}

	public float getRateOfInterest() {
		return RateOfInterest;
	}

	public void setRateOfInterest(float rateOfInterest) {
		RateOfInterest = rateOfInterest;
	}

	public double getCourseFee() {
		return CourseFee;
	}

	public void setCourseFee(double courseFee) {
		CourseFee = courseFee;
	}

	public String getCourse() {
		return Course;
	}

	public void setCourse(String course) {
		Course = course;
	}

	public String getFatherName() {
		return FatherName;
	}

	public void setFatherName(String fatherName) {
		FatherName = fatherName;
	}

	public String getFatherOccupation() {
		return FatherOccupation;
	}

	public void setFatherOccupation(String fatherOccupation) {
		FatherOccupation = fatherOccupation;
	}

	public int getFatherTotalExp() {
		return FatherTotalExp;
	}

	public void setFatherTotalExp(int fatherTotalExp) {
		FatherTotalExp = fatherTotalExp;
	}

	public int getFatherExpwCC() {
		return FatherExpwCC;
	}

	public void setFatherExpwCC(int fatherExpwCC) {
		FatherExpwCC = fatherExpwCC;
	}

	public String getRationCard() {
		return RationCard;
	}

	public void setRationCard(String rationCard) {
		RationCard = rationCard;
	}

	public double getAnnualIncome() {
		return AnnualIncome;
	}

	public void setAnnualIncome(double annualIncome) {
		AnnualIncome = annualIncome;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public int getTotalExp() {
		return TotalExp;
	}

	public void setTotalExp(int totalExp) {
		TotalExp = totalExp;
	}

	public int getExpCC() {
		return ExpCC;
	}

	public void setExpCC(int expCC) {
		ExpCC = expCC;
	}

	public void setDurationLoan(int durationLoan) {
		DurationLoan = durationLoan;
	}

	public int getDurationLoan() {
		return DurationLoan;
	}

	public void setCustid(String custid) {
		Custid = custid;
	}

	public String getCustid() {
		return Custid;
	}

	public void setLoanAccNo(String loanAccNo) {
		LoanAccNo = loanAccNo;
	}

	public String getLoanAccNo() {
		return LoanAccNo;
	}

	public void setEMI(double eMI) {
		EMI = eMI;
	}

	public double getEMI() {
		return EMI;
	}

	public String getGuarantorName() {
		return GuarantorName;
	}

	public void setGuarantorName(String guarantorName) {
		GuarantorName = guarantorName;
	}

	public String getGuarantorAddress() {
		return GuarantorAddress;
	}

	public void setGuarantorAddress(String guarantorAddress) {
		GuarantorAddress = guarantorAddress;
	}

	public double getGuarantorIncome() {
		return GuarantorIncome;
	}

	public void setGuarantorIncome(double guarantorIncome) {
		GuarantorIncome = guarantorIncome;
	}

}
