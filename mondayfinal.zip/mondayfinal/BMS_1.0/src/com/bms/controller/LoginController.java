package com.bms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.LoginBean;
import com.bms.bo.LoginBO;

public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(LoginController.class);

	LoginBean lb = null;
	LoginBO l = null;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		lb = new LoginBean();
		l = new LoginBO();

		String check = new String();

		LOG.info("inside Logincontroller");

		try {
			String s = request.getParameter("username");

			if (!s.isEmpty()) {
				lb.setUsername(s);
				// System.out.println("ye vala" + s);
			} else {
				throw new BusinessException("Invalid UserName");
			}
			String p = request.getParameter("password");
			if (!p.isEmpty()) {
				lb.setPassword(p);
				// System.out.println("yaha vala" + s);
			} else {
				throw new BusinessException("Invalid password");
			}

			/*
			 * String username = request.getParameter("username"); String pswd =
			 * request.getParameter("password"); if (!username.isEmpty() &&
			 * !pswd.isEmpty()) { lb.setUsername(username);
			 * lb.setPassword(pswd); } else { //
			 * System.out.println("Galat admi hai tu"); throw new
			 * BusinessException("UserName/Password does not match");
			 * 
			 * }
			 */
			check = l.checkLogin(lb);
			if (!s.isEmpty() && !p.isEmpty() && check == null) {
				System.out.println("Galat admi	");
				PrintWriter writer = response.getWriter();
				// writer.println("INVALID USER");
				throw new BusinessException("UserName/Password does not match");
			}
			// if (!check.equals(null))
			else { // if customer id present and not null
					// TRUE
				HttpSession session = request.getSession();
				session.setAttribute("Customer_Id", check);
				session.setAttribute("username", lb.getUsername());
				RequestDispatcher disp = request
						.getRequestDispatcher("Welcome.jsp");
				disp.forward(request, response);
			} /*
			 * else { // throw new //
			 * BusinessException("UserName/Password does not match");
			 * PrintWriter writer = response.getWriter();
			 * writer.println("INVALID USER"); }
			 */
		} catch (BusinessException le) {
			// LOG.error("Exception from Login Controller..." +
			// le.getMessage();
			request.setAttribute("Message", le.getMessage());
			RequestDispatcher disp = request.getRequestDispatcher("Login.jsp");
			disp.forward(request, response);
		} catch (Exception e) {
			// LOG.error("Exception from Login Controller..." + e.getMessage());
			request.setAttribute("Message", "FatalError occured");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Login.jsp");
			dispatch.forward(request, response);
		}
	}
}