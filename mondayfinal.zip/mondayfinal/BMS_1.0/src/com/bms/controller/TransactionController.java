package com.bms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;
import com.bms.bean.TransactionBean;
import com.bms.bo.TransactionBO;

public class TransactionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static Logger LOG = Logger.getLogger(TransactionController.class);

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		LOG.info("inside Transaction Controller-do Post method");
		String CustIdOfLogin = (String) session.getAttribute("Customer_Id");
		try {
			TransactionBean user = new TransactionBean();
			TransactionBO bo = new TransactionBO();
			user.setAccount_Number(request.getParameter("acnumber"));
			user.setAccount_Holder_Name(request.getParameter("acname"));
			user.setAccount_Type(request.getParameter("actype"));
			user.setTransaction_Type(request.getParameter("trantype"));
			user.setTransaction_Date(request.getParameter("trandate"));

			if (request.getParameter("amnt").isEmpty())
				throw new BusinessException("Amount cannot be blank");
			else {
				for (int i = 0; i < request.getParameter("amnt").length(); i++) {
					if (!Character.isDigit(request.getParameter("amnt").charAt(
							i)))
						throw new BusinessException("Amount can be only digits");
				}
				user.setAmount(Double.parseDouble(request.getParameter("amnt")));
			}
			String check[] = bo.checkAmount(user, CustIdOfLogin);
			if (Integer.parseInt(check[0]) == 1) {

				request.setAttribute("Balance", check); // setting Balance
				request.setAttribute("message", "Success");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("TransactionFetch.jsp");
				dispatcher.forward(request, response);

			} else {
				request.setAttribute("message", "Error");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("TransactionFetch.jsp");
				dispatcher.forward(request, response);
			}
		} catch (BusinessException e) {
			request.setAttribute("message", e.getMessage());
			LOG.error("inside Transaction controller  Business Exception"
					+ e.getMessage());
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Transaction.jsp");
			dispatch.forward(request, response);
		} catch (NumberFormatException e) {
			LOG.error("inside Transaction controller  error occurs"
					+ e.getMessage());
			request.setAttribute("message", "Amount can not be empty ");
			RequestDispatcher dispatch = request
					.getRequestDispatcher("Transaction.jsp");
			dispatch.forward(request, response);
		} catch (Exception e) {
			LOG.error("inside Transaction controller  error occurs"
					+ e.getMessage());
			request.setAttribute("message", "Error");
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("TransactionFetch.jsp");
			dispatcher.forward(request, response);
		}
	}
}
