package com.bms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.bms.BusinessException.BusinessException;

public class PropertyUtil {
	public static Logger LOG = Logger.getLogger(PropertyUtil.class);
	private Connection conn = null;
	Statement stmt = null;
	ResultSet rs = null;
	ResultSet rs1 = null;

	public static String getMessage(String key) {
		Locale locale = Locale.getDefault();
		ResourceBundle bundle = ResourceBundle.getBundle("Message", locale);
		return bundle.getString(key);
	}

	public Connection connections() throws SQLException {
		LOG.info("inside propertyutil creating connection with database");
		String str = "jdbc:mysql://localhost:3306/bank4";

		String userName = "root";
		String pwd = "root";
		/*
		 * String str = PropertyUtil.getMessage("501"); String userName =
		 * PropertyUtil.getMessage("502"); String pwd =
		 * PropertyUtil.getMessage("503");
		 */
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (Exception e) {
			LOG.error("exception in  creating class " + e.getMessage());
		}
		conn = DriverManager.getConnection(str, userName, pwd);
		return conn;
	}

	public void CloseConnection() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String generateCountryId(String country, String state)
			throws ClassNotFoundException, SQLException {
		LOG.info("inside generate country id");
		String query = "select Country_Id from country_details where Country_Name like'"
				+ country + "' and State like'" + state + "'";
		String s = new String();
		try {
			conn = connections();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				s = rs.getString(1);
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return s;
	}

	public String generateIFSC(String branch_name) throws SQLException {
		LOG.info("inside propertyutil generate ifsc code");
		String query = "select IFSC_Code from branch_info where Branch_Name like'"
				+ branch_name + "'";
		String s = null;
		try {
			conn = connections();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				s = rs.getString(1);
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return s;
	}

	public java.sql.Date utilDateToSqlDate(String s) throws ParseException {
		LOG.info("inside propertyutil converting string to sql date");
		java.sql.Date sqlDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date d = sdf.parse(s);
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
		String s2 = sdf1.format(d);
		java.util.Date dn = sdf1.parse(s2);
		sqlDate = new java.sql.Date(dn.getTime());
		LOG.error("After changing string to sql date");
		return sqlDate;
	}

	public ArrayList<String> regSelectCountryQuery() throws SQLException,
			ClassNotFoundException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn = connections();
			String query = "select distinct Country_Name from country_details order by Country_Name";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				list.add(rs.getString(1));
			}
		} finally {
			if (stmt != null)
				stmt.close();
			if (rs != null)
				rs.close();
		}
		return list;
	}

	public ArrayList<String> getStates(String country_name) throws SQLException {
		System.out.println(country_name);
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn = connections();
			stmt = conn.createStatement();
			rs = stmt
					.executeQuery("select state from country_details where Country_Name='"
							+ country_name + "'" + " order by state");

			while (rs.next()) {
				String s = rs.getString(1);
				System.out.println(s);
				list.add(s);

			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return list;
	}

	public ArrayList<String> regSelectBranch() throws SQLException,
			ClassNotFoundException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn = connections();
			String query = "select distinct Branch_Name from branch_info order by Branch_Name";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				list.add(rs.getString(1));
			}
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		return list;
	}

	public ArrayList<String> refAccNo(String accno) throws SQLException,
			BusinessException {
		ArrayList<String> list = new ArrayList<String>();
		try {
			conn = connections();
			stmt = conn.createStatement();
			String query = "Select count(*) from Account_Info";
			rs = stmt.executeQuery(query);
			int n = 0;
			while (rs.next()) {
				n = rs.getInt(1);
			}
			if (n >= 1) {
				String query1 = "select Name,Address from Customer_details where Customer_Id =(select Customer_Id from Account_Info where Account_Number='"
						+ accno + "')";
				rs1 = stmt.executeQuery(query1);
				while (rs1.next()) {
					list.add(rs1.getString(1));
					list.add(rs1.getString(2));
				}
			} else
				throw new BusinessException("Invalid reference account number");
		} finally {
			if (rs != null)
				rs.close();
			if (rs1 != null)
				rs1.close();
			if (stmt != null)
				stmt.close();
		}
		return list;
	}

}
