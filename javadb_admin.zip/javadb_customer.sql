CREATE DATABASE  IF NOT EXISTS `javadb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `javadb`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: javadb
-- ------------------------------------------------------
-- Server version	5.0.81-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `ID` int(11) NOT NULL auto_increment,
  `NAME` varchar(30) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `CONTACT_NO` varchar(10) NOT NULL,
  `REG_DATE` date NOT NULL,
  `documentDetailNumber` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `COUNTRY_ID` varchar(10) NOT NULL,
  `CARD_NO` varchar(30) NOT NULL,
  `vendorType` varchar(45) NOT NULL,
  `vendorName` varchar(45) NOT NULL,
  `documentName` varchar(45) NOT NULL,
  PRIMARY KEY  (`ID`),
  KEY `COUNTRY_ID` (`COUNTRY_ID`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `country` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1013 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1000,'Rashmi','Pune','9856321478','2013-03-12','F654378','rashmi@gmail.com','1','9874562314569874','Telephone','chetan','voterid'),(1002,'TAmmay','abcd','9975103001','2012-02-02','DXGCFV','output@gmail.com','1','345678','2CVB','2CVB','2CVB'),(1003,'Rashmi','address','1234567890','2017-04-20','GMV1234','email@id.com','1','45678','Telephone','abc','VoterId'),(1004,'abc','asdsd','1234567890','2017-04-20','GMV1232323','aas@ashg.com','1','54564132465','Telephone','abc','VoterId'),(1005,'shhja45','saaaa65','454','2017-04-21','GMV314313','xsaxsaas','1','645','Telephone','asxsa','VoterId'),(1006,'Shubham','Nashik','8456974561','2017-04-21','DLG9876','shubham@yahoo.com','3','7456845694456321','Tax','Sacchai Tax Services','DrivingLicense'),(1007,'Shubham','Nashik','8456974561','2017-04-21','DLG9876','shubham@yahoo.com','3','7456845694456321','Tax','Sacchai Tax Services','DrivingLicense'),(1008,'Shubham','Nashik','8456974561','2017-04-21','DLG9876','shubham@yahoo.com','3','7456845694456321','Tax','Sacchai Tax Services','DrivingLicense'),(1009,'Shubham','Nashik','8456974561','2017-04-21','DLG9876','shubham@yahoo.com','3','7456845694456321','Tax','Sacchai Tax Services','DrivingLicense'),(1010,'Shubham','Nashik','8456974561','2017-04-21','DLG9876','shubham@yahoo.com','3','7456845694456321','Tax','Sacchai Tax Services','DrivingLicense'),(1011,'Abna','Kanyakumari','9856321478','2017-04-21','DLH3556','abna@yahoo.com','3','7896541236958745','Telephone','Vodafone','DrivingLicense'),(1012,'Aditya ','NewJersey','9856214562','2017-04-22','PANOG7665','aditya@hotmail.com','3','1234567898765432','Electricity','MSEB','PANCard');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-22 15:25:13
