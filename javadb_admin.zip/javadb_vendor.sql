CREATE DATABASE  IF NOT EXISTS `javadb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `javadb`;
-- MySQL dump 10.13  Distrib 5.5.16, for Win32 (x86)
--
-- Host: localhost    Database: javadb
-- ------------------------------------------------------
-- Server version	5.0.81-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `ID` int(11) NOT NULL,
  `COUNTRY_ID` varchar(10) NOT NULL,
  `COMPANY_REG_NO` varchar(10) NOT NULL,
  `TYPE` varchar(30) NOT NULL,
  `YOS` int(11) NOT NULL,
  `CERTIFICATE_ISSUE_DATE` date default NULL,
  `CERTIFICATE_VALIDITY_DATE` date default NULL,
  `CONTACT_NO` varchar(10) NOT NULL,
  `WEBSITE` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `AMOUNT` float NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `EMPLOYEE_COUNT` int(11) NOT NULL,
  PRIMARY KEY  (`ID`),
  KEY `COUNTRY_ID` (`COUNTRY_ID`),
  CONSTRAINT `vendor_ibfk_1` FOREIGN KEY (`COUNTRY_ID`) REFERENCES `country` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` VALUES (1,'1','2345','Telephone',2,NULL,NULL,'9874563214','www.abc.com','abc@gmail.com',100,'chetan','pune',100),(2,'1','1234','Telephone',23,'2017-04-20','2032-04-20','1234567890','https://www.asdas.com','asd@qwe.com',2000,'abc','abcd',100),(3,'1','PD09876','Electricity',8,'2017-04-21','2032-04-21','9546871236','https://www.ankitaenterprises.com','ankitaenterprises@yahoo.com',1000,'Ankita Enterprises','Kharadi, Nagpur',130),(4,'1','4597','Tax',16,'2017-04-21','2032-04-21','8456971236','https://www.sacchaitax.com','sacchaitax@gmail.com',700,'Sacchai Tax Services','Gulmarg, Kashmir',96),(5,'1','8876','Insurance',7,'2017-04-21','2032-04-21','9089465627','https://www.pallaviinsurance.com','pallaviinsurance@gmail.com',1200,'Pallavi Insurance Company ','Dehradun',90),(6,'1','REG 1235','Tax',9,'2017-04-22','2032-04-22','9975103002','https://www.consultancy.com','consultancyfirm@gmail.com',700,'Consultancy Firm','Pune ',52),(7,'1','REG156','Insurance',6,'2017-04-22','2032-04-22','9766321545','https://anuBima.com','anubeema@yahoo.com',1200,'AnuBima','Aurangabad',56),(8,'1','REG123','Electricity',37,'2017-04-22','2032-04-22','8956234512','https://www.mahanirman.com','maha@hotmail.com',1000,'Mahagenco','Nagpur',9000),(9,'1','reg123','Electricity',37,'2017-04-22','2032-04-22','2356897845','https://www.mahagen.com','mahagen@gmail.com',1000,'mahagen','daqwdxw',9000),(10,'1','dsasda','Electricity',37,'2017-04-22','2032-04-22','4512124545','https://www.dsfsfs.com','fdsff@gmail.com',1000,'sdada','sdcsdf',600),(11,'1','sfssd','Insurance',37,'2017-04-22','2032-04-22','4512235689','https://www.csacc.com','scsdc@gmail.com',1200,'ddsdvdfvg','dsfcs',600),(12,'3','REG123','Electricity',32,'2017-04-22','2032-04-22','9632587412','https://www.maha.com','maha@yahoo.com',1000,'maha','Eden Stadium',600);
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-22 15:25:17
